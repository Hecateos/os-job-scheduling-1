make clean
make
./job
