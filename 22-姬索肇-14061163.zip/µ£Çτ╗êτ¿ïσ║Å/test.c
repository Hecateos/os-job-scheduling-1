#include "time.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#define MAXTIME 10
#define IFSTOP 0

void myclock(int x)
{
	time_t timer,timerc;
	int count=1;  
	struct tm *timeinfo;
	time(&timer);//系统开始的时间
	while(1)
	{
		time(&timerc);
		if((timerc-timer)>=1)//每过1秒打印
		{
			printf("[程序%d]时间过去了%d秒\n",x,count++);	
			if(IFSTOP&&count>=MAXTIME){
				printf("##到点了～##\n");
				return;	
			}
			timer=timerc;
		}
	}
  
}

void main(int argc,char *argv[])
{
	
	if(argc==1)	
		myclock(0);
	else
		myclock(atoi(argv[1]));
	
	//	queuemain();
}

