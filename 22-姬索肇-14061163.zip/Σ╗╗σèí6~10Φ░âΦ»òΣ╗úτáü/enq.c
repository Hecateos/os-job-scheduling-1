#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"
#define DEBUG
/* 
 * 命令语法格式
 *     enq [-p num] e_file args
 */
void usage()
{
	printf("Usage: enq[-p num] e_file args\n"
		"\t-p num\t\t specify the job priority\n"
		"\te_file\t\t the absolute path of the exefile\n"
		"\targs\t\t the args passed to the e_file\n");
}

int main(int argc,char *argv[])
{
	int p=1;//jsz note p代表作业优先级 change 修改默认值为1
	int fd;
	char c,*offset;
	struct jobcmd enqcmd;

	//if(MYDEBUG)printf("[MY]argc:%d\n",argc);//jsz add 
	if(argc==1)//jsz note argc代表参数个数，如输入./enq Demo 则argc=2
	{
		usage();//jsz note 如果只输入了./enq 则输出用法
		return 1;
	}

	while(--argc>0 && (*++argv)[0]=='-')
	{
		while(c=*++argv[0])
			switch(c)
		{
			case 'p':p=atoi(*(++argv));//jsz note 将-p后面的数字转换为int，然后保存到变量ｐ中
			argc--;
			break;
			default:
				printf("Illegal option %c\n",c);
				return 1;
		}
	}

	if(p<1||p>3)//jsz note 如果优先级不是0~3则输出错误信息 change 修改为1~3
	{
		printf("invalid priority:must between 1 and 3\n");
		return 1;
	}

	enqcmd.type=ENQ;//jsz note 命令的种类，包括ENQ,DEQ,STAT
	enqcmd.defpri=p;//jsz note 设置默认优先级为ｐ
	enqcmd.owner=getuid();//jsz note 设置作业所属用户　getuid()函数的功能是返回调用程序的真实用户id
	enqcmd.argnum=argc;//jsz note 参数个数
	offset=enqcmd.data;

	while (argc-->0)
	{
		strcpy(offset,*argv);
		strcat(offset,":");
		offset=offset+strlen(*argv)+1;
		argv++;
	}

    #ifdef DEBUG
		printf("enqcmd cmdtype\t%d\n"
			"enqcmd owner\t%d\n"
			"enqcmd defpri\t%d\n"
			"enqcmd data\t%s\n",
			enqcmd.type,enqcmd.owner,enqcmd.defpri,enqcmd.data);

    #endif 

		if((fd=open("/tmp/server",O_WRONLY))<0)//jsz note 以只写方式打开FIFO文件，准备写入，文件标识符是fd
			error_sys("enq open fifo failed");

		if(write(fd,&enqcmd,DATALEN)<0)//jsz note 向FIFO文件写入enqcmd信息，DATALEN是sizeof(struct jobcmd)，即enqcmd的长度，job.c会每隔１s读取一次
			error_sys("enq write failed");

		close(fd);
		return 0;
}

