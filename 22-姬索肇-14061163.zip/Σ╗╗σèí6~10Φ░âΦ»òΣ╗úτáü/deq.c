#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"

/* 
 * 命令语法格式
 *     deq jid
 */
void usage()
{
	printf("Usage: deq jid\n"
		"\tjid\t\t the job id\n");
}

int main(int argc,char *argv[])
{
	struct jobcmd deqcmd;
	int fd;
	
	if(argc!=2)//jsz note 如果输入的参数不是2个，那么输出用法
	{
		usage();
		return 1;
	}

	deqcmd.type=DEQ;//jsz note 设置命令类型为DEQ
	deqcmd.defpri=1;//jsz change 修改默认优先级为１
	deqcmd.owner=getuid();//jsz note 设置所有者id
	deqcmd.argnum=1;//jsz note 设置参数个数为１

	strcpy(deqcmd.data,*++argv);//jsz note 将参数信息拷贝到deqcmd.data中，以便输出
	printf("jid %s\n",deqcmd.data);


	if((fd=open("/tmp/server",O_WRONLY))<0)//jsz note 以只写形式打开FIFO文件，文件标识符为fd
		error_sys("deq open fifo failed");

	if(write(fd,&deqcmd,DATALEN)<0)//jsz note 向FIFO文件中写入deqcmd
		error_sys("deq write failed");

	close(fd);
	return 0;
}
