#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"

/* 
 * 命令语法格式
 *     stat
 */
void usage()
{
	printf("Usage: stat\n");		
}

int main(int argc,char *argv[])
{
	struct jobcmd statcmd;
	int fd;

	if(argc!=1)//jsz note 如果参数不是一个则输出用法
	{
		usage();
		return 1;
	}

	statcmd.type=STAT;//jsz note 设置命令类型为STAT
	statcmd.defpri=1;//jsz note 默认优先级为０ change 默认优先级为1
	statcmd.owner=getuid();//jsz note 获得用户id
	statcmd.argnum=0;//jsz note 参数个数为０


	if((fd=open("/tmp/server",O_WRONLY))<0)//jsz note 以只写形式打开FIFO文件，文件标识符为fd
		error_sys("stat open fifo failed");

	if(write(fd,&statcmd,DATALEN)<0)//jsz note 向FIFO文件中写入statcmd
		error_sys("stat write failed");

	close(fd);
	return 0;
}
