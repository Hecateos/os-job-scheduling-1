#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include "job.h"

int jobid=0;
int siginfo=1;
int fifo;
int globalfd;

struct waitqueue *head=NULL;
struct waitqueue *next=NULL,*current =NULL;
struct waitqueue *queue[4]={NULL,NULL,NULL,NULL};//jsz add 多级队列
/* 调度程序 */
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	int  count = 0;
	bzero(&cmd,DATALEN);//jsz note bzero函数的功能是将字符串的前n个字符置零,DATALEN是宏定义的sizeof(struct jobcmd)
	if((count=read(fifo,&cmd,DATALEN))<0)//count为读到的字节数
		error_sys("read fifo failed");
#ifdef DEBUG
	printf("Reading whether process send command!\n");//hlx add 任务三
	if(count>0){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);
	}
//	else
//		printf("no data read\n");
#endif

	/* 更新等待队列中的作业 */
	/*hlx add任务三*/
	#ifdef DEBUG
		printf("Update jobs in wait queue!\n");	
	#endif
	//............................
	updateall();//jsz note 调用updateall函数，该函数在下面定义

	switch(cmd.type){//jsz note cmd.type代表作业的种类，根据不同的种类调用不同的处理函数
	case ENQ:
		/*hlx add任务三*/
		#ifdef DEBUG
			printf("Execute enq!\n");
		#endif
		//........................
		do_enq(newjob,cmd);
		break;
	case DEQ:
		/*hlx add任务三*/
		#ifdef DEBUG
			printf("Execute deq!\n");
		#endif
		//........................
		do_deq(cmd);
		break;
	case STAT:
		/*hlx add任务三*/
		#ifdef DEBUG
			printf("Execute stat!\n");
		#endif
		//........................
		do_stat(cmd);
		break;
	default:
		break;
	}

	/* 选择高优先级作业 */
	/*hlx add任务三*/
	#ifdef DEBUG
		printf("Select which job to run next!\n");
	#endif
	//.............................
	next=jobselect();//jsz note 将cmd处理之后，选择高优先级的作业，以便之后切换
	/* 作业切换 */
	/*hlx add任务三*/
	#ifdef DEBUG
		printf("Switch to the next job!\n");
	#endif
	//.............................
	jobswitch();//jsz note　根据优先级切换当前运行的作业current
}

int allocjid()
{
	return ++jobid;
}

void updateall()//jsz note updateall函数的功能是更新所有作业的等待时间和优先级
{
	struct waitqueue *p;

	/* 更新作业运行时间 */
	if(current)
		current->job->run_time += 1; /* 加1代表1000ms */

	/* 更新作业等待时间及优先级 */
	for(p = head; p != NULL; p = p->next){
		p->job->wait_time += 1000;//jsz note 作业的等待时间提升
		if(p->job->wait_time >= 10000 && p->job->curpri < 3){//jsz change 等待时间由5000改为10000
			p->job->curpri++;//jsz note 作业的当前优先级提高
			p->job->wait_time = 0;
		}
	}
}

struct waitqueue* jobselect(){//jsz note jobselect函数的功能是选择优先级最高的作业
	struct waitqueue *p,*prev,*select,*selectprev;
	int highest = -1;//jsz note highest保存当前最高的优先级

	select = NULL;
	selectprev = NULL;
	if(head){
		/* 遍历等待队列中的作业，找到优先级最高的作业 */
		for(prev = head, p = head; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;//jsz note select代表优先级最高的结点
				selectprev = prev;//jsz note selectprev代表优先级最高的结点的前一个结点
				highest = p->job->curpri;
			}
		selectprev->next = select->next;
		//if (select == selectprev)//jsz note 这里有bug，如果等待队列优先级最高的作业在链表头部，会将head设为NULL，导致整个链表丢失
		//	head = NULL;
		//jsz add　Bug2修复
		if(select==selectprev){//如果选中的优先级最高的作业在队列的头部
			if(select->next==NULL){
				head=NULL;
			}
			else{
				head=select->next;
				select->next=NULL;
			}
		}	
		else{
			select->next=NULL;//jsz add 修复Bug4，使得select不会与等待队列相连
		}		
		//...
	}
	/*hlx add任务八*/
	#ifdef DEBUG
	char timebuf[BUFLEN];
	if (select!=NULL){
	printf("jobselect DEBUG info\n");
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	strcpy(timebuf,ctime(&(select->job->create_time)));
	timebuf[strlen(timebuf)-1]='\0';
	printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
		select->job->jid,
		select->job->pid,
		select->job->ownerid,
		select->job->run_time,
		select->job->wait_time,
		timebuf,
		"READY");
	}
	printf("info end\n");
	#endif
	//..............
	return select;
}

void jobswitch()//jsz note 判断当前作业是否完成，如果完成将current清除，然后根据优先级，更新current
{
	struct waitqueue *p;
	int i;

	if(current && current->job->state == DONE){ /* 当前作业完成 */
		/* 作业完成，删除它 */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* 释放空间 */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}

	if(next == NULL && current == NULL) /* 没有作业要运行 */

		return;
	else if (next != NULL && current == NULL){ /* 开始新的作业 */

		printf("begin start new job\n");
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		kill(current->job->pid,SIGCONT);//jsz note SIGCONT是继续信号，告诉新作业要继续运行
		return;
	}
	else if (next != NULL && current != NULL){ /* 切换作业 */

		printf("switch to Pid: %d\n",next->job->pid);
		kill(current->job->pid,SIGSTOP);//jsz note SIGSTOP是暂停信号，使当前作业暂停运行
		current->job->curpri = current->job->defpri;
		current->job->wait_time = 0;
		current->job->state = READY;//jsz note 更新当前作业的状态为READY等待

		/* 放回等待队列 */
		if(head){
			for(p = head; p->next != NULL; p = p->next);
			p->next = current;
		}else{
			head = current;
		}
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		current->job->wait_time = 0;
		kill(current->job->pid,SIGCONT);//jsz note 发送SIGCONT，告诉新的current作业继续运行
		return;
	}else{ /* next == NULL且current != NULL，不切换 */
		return;
	}
}

void sig_handler(int sig,siginfo_t *info,void *notused)
{
	int status;
	int ret;

	switch (sig) {
case SIGVTALRM: /* 到达计时器所设置的计时间隔 */
	scheduler();
	/*hlx add任务二*/	
	#ifdef DEBUG
		printf("SIGVTALRM RECEIVED!\n");
	#endif
	//.......................................
	return;
case SIGCHLD: /* 子进程结束时传送给父进程的信号 */
	ret = waitpid(-1,&status,WNOHANG);//jsz note 等待子进程完成，status保存子进程的结束状态
	if (ret == 0)
		return;
	if(WIFEXITED(status)){//jsz note 子进程正常结束，WIFEXITED(status)的值为真
		current->job->state = DONE;
		printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
	}else if (WIFSIGNALED(status)){//jsz note 子进程异常结束，WIFSIGNALED(status)的值为真
		printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
	}else if (WIFSTOPPED(status)){//jsz note 子进程暂停时，WIFSTOPPED(status)的值为真
		printf("child stopped, signal number = %d\n",WSTOPSIG(status));
	}
	return;
	default:
		return;
	}
}

void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd)//jsz note 增加作业处理函数
{
	struct waitqueue *newnode,*p;
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;

	sigemptyset(&zeromask);

	/* 封装jobinfo数据结构 */
	newjob = (struct jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();//jsz note 设置作业id
	newjob->defpri = enqcmd.defpri;//jsz note 设置默认优先级
	newjob->curpri = enqcmd.defpri;//jsz note 设置当前优先级
	newjob->ownerid = enqcmd.owner;//jsz note 设置作业所有者id
	newjob->state = READY;//jsz note 设置作业的状态
	newjob->create_time = time(NULL);//jsz note 设置作业的创建时间，time()函数的返回值类型是time_t
	newjob->wait_time = 0;//jsz note 作业等待时间初值为０
	newjob->run_time = 0;//jsz note 作业运行时间初值为０
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));
	newjob->cmdarg = arglist;
	offset = enqcmd.data;
	argvec = enqcmd.data;//jsz　note　将作业参数拷贝到argvec
	while (i < enqcmd.argnum){
		if(*offset == ':'){
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;

#ifdef DEBUG

	printf("enqcmd argnum %d\n",enqcmd.argnum);
	for(i = 0;i < enqcmd.argnum; i++)
		printf("parse enqcmd:%s\n",arglist[i]);

#endif

	/*向等待队列中增加新的作业*/
	newnode = (struct waitqueue*)malloc(sizeof(struct waitqueue));
	newnode->next =NULL;//jsz note 等待队列是一个链表结构，此操作往链表中加入了一个新的结点
	newnode->job=newjob;

	if(head)
	{
		for(p=head;p->next != NULL; p=p->next);
		p->next =newnode;
	}else
		head=newnode;

	/*为作业创建进程*/
	if((pid=fork())<0)//jsz note 从此步开始创建子进程，子进程结束时会向父进程发出SIGCHLD信号，会被sig_handler收到
		error_sys("enq fork failed");

	if(pid==0){//jsz note 子进程执行部分
		newjob->pid =getpid();//jsz note 获得子进程的pid
		/*阻塞子进程,等等执行*/
		raise(SIGSTOP);//jsz note raise函数与kill函数类似，能够发送信号，raise函数允许进程向自身发送信号
#ifdef DEBUG

		printf("begin running\n");
		for(i=0;arglist[i]!=NULL;i++)
			printf("arglist %s\n",arglist[i]);
#endif

		/*复制文件描述符到标准输出*/
		dup2(globalfd,1);//jsz note 将标准输出重定向到文件globalfd,即printf的结果写入文件而不是在终端输出
		/* 执行命令 */
		if(execv(arglist[0],arglist)<0)//jsz note 使用execv调用外部命令,如果调用成功，子进程将被替换
			printf("exec failed\n");
		exit(1);
	}else{//jsz note 父进程执行部分
		sleep(1);//jsz add 稍等一会儿，使子进程执行到raise(SIGSTOP)
		newjob->pid=pid;//jsz note 将子进程的pid保存到newjob中，然后回到scheduler()继续执行
	}
}

void do_deq(struct jobcmd deqcmd)//jsz note 删除作业处理函数
{
	int deqid,i;
	struct waitqueue *p,*prev,*select,*selectprev;
	deqid=atoi(deqcmd.data);//jsz note atoi函数将字符串转换为int

#ifdef DEBUG
	printf("deq jid %d\n",deqid);
#endif

	/*current jodid==deqid,终止当前作业*/
	if (current && current->job->jid ==deqid){//jsz note current是struct waitqueue类型的指针，代表当前作业
		printf("teminate current job\n");
		kill(current->job->pid,SIGKILL);//jsz note 向当前作业的子进程发送SIGKILL信号，强行使子进程终止
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){//jsz note 将作业的参数清空
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{ /* 或者在等待队列中查找deqid */
		select=NULL;
		selectprev=NULL;
		if(head){//jsz note 如果等待队列中有作业则执行下列操作
			for(prev=head,p=head;p!=NULL;prev=p,p=p->next)//jsz note 等待队列是一个链表，顺序查找deqid
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
			selectprev->next=select->next;
				//if (select == selectprev)//jsz note 这里有bug，如果等待队列优先级最高的作业在链表头部，会将head设为NULL，导致整个链表丢失
				//	head = NULL;
			//jsz add Bug3修复
			if(select==selectprev){
				if(select->next==NULL){
					head=NULL;
				}
				else{
					head=select->next;
					select->next=NULL;
				}
			}
			else{
				select->next=NULL;//jsz add 修复Bug4，使select不会与等待队列相连
			}		
			//...
		}
		if(select){//jsz note 如果已经找到了deqid，则将其清除
			for(i=0;(select->job->cmdarg)[i]!=NULL;i++){
				free((select->job->cmdarg)[i]);
				(select->job->cmdarg)[i]=NULL;
			}
			free(select->job->cmdarg);
			free(select->job);
			free(select);
			select=NULL;
		}
	}
}

void do_stat(struct jobcmd statcmd)//jsz note 打印信息处理函数
{
	struct waitqueue *p;
	char timebuf[BUFLEN];
	/*
	*打印所有作业的统计信息:
	*1.作业ID
	*2.进程ID
	*3.作业所有者
	*4.作业运行时间
	*5.作业等待时间
	*6.作业创建时间
	*7.作业状态
	*/

	/* 打印信息头部 */
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if(current){//jsz note 如果当前作业正在运行,输出当前作业的信息
		strcpy(timebuf,ctime(&(current->job->create_time)));//jsz note ctime函数的功能是将时间转换为字符串，本代码将当前作业的创建时间拷贝到timebuf中
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
	}

	for(p=head;p!=NULL;p=p->next){//jsz note 输出等待队列中的作业信息
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
	}
}

int main()
{
	struct timeval interval;
	struct itimerval new,old;
	struct stat statbuf;
	struct sigaction newact,oldact1,oldact2;

	/*hlx add任务一*/
	#ifdef DEBUG
		printf("DEBUG IS OPEN!");
	#endif
	//...........................

	if(stat("/tmp/server",&statbuf)==0){
		/* 如果FIFO文件存在,删掉 */
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/server",0666)<0)
		error_sys("mkfifo failed");
	/* 在非阻塞模式下打开FIFO */
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)//jsz note 通过open函数打开FIFO文件/tmp/server，文件标识符是fifo,用于读写操作
		error_sys("open fifo failed");

	/* 建立信号处理函数 */
	newact.sa_sigaction=sig_handler;//jsz note sig_handler是信号处理函数，能够处理SIGCHLD信号和SIGVTALRM信号
	sigemptyset(&newact.sa_mask);
	newact.sa_flags=SA_SIGINFO;
	sigaction(SIGCHLD,&newact,&oldact1);//jsz note newact中指定了sig_handler是信号处理函数，本条声明SIGCHLD由sig_handler处理
	sigaction(SIGVTALRM,&newact,&oldact2);//jsz note 声明SIGVTALRM由sig_handler处理

	/* 设置时间间隔为1000毫秒 */
	interval.tv_sec=1;
	interval.tv_usec=0;

	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);//jsz note 产生信号，能够产生SIGVTALRM信号

	while(siginfo==1);//jsz note　产生一个死循环，使程序一直运行

	close(fifo);
	close(globalfd);
	return 0;
}
