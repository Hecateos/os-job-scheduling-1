#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include "job.h"

//#define DEBUG
//#define rundebug
#define FIFO "/tmp/MYFIFO"
#define BUFLEN 100


int jobid=0;
int siginfo=1;
int fifo;
int globalfd;
int k=1;
int needruntime=0;
//int goon=0;//���ڵȴ��źţ�bug1

/*struct reaction_queue rl[LEVELS];//ָ����е��׵�ַ������;
void reaction_inital(struct reaction p[],int n){
    	int i;
    	for(i=0;i<n;i++){//һ����3�У��ֱ�ʱ��ƬΪ1��2��5;
    		if(0==i)p[i].time_slice=1;
    		else if(1==i)p[i].time_slice=2;
    		else if(2==i)p[i].time_slice=5;
    		p[i]->head=NULL;	//��ʼ��ÿ������ͷָ��	
    	}
	
}*/

struct waitqueue *head0=NULL,*head1=NULL,*head2=NULL;//process_task ��ʼ��
struct waitqueue *next=NULL,*current =NULL;



/*void setGoon(){
    goon = 1;
}*/

/* ���ȳ��� */
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	struct waitqueue *p=NULL;
	int  count = 0;
	int time_piece=0;
	int ifenq=0;
	int blevel=0;
	
	bzero(&cmd,DATALEN);
	if((count=read(fifo,&cmd,DATALEN))<0)
		error_sys("read fifo failed");
#ifdef DEBUG
	printf("Reading whether other process send command!\n");
	if(count){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);
	}
#endif

	/* ���µȴ������е���ҵ */
#ifdef DEBUG
	printf("Update jobs in wait queue!\n");
#endif
//������
#ifdef DEBUG
	for(p=head2;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head1;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head0;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
#endif
			
	updateall();
	
//������
#ifdef DEBUG
	for(p=head2;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head1;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head0;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
#endif


//������
#ifdef DEBUG
	for(p=head2;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head1;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head0;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
#endif
	switch(cmd.type){
	case ENQ:
	#ifdef DEBUG
		printf("Execute enq!\n");
	#endif
		do_enq(newjob,cmd);
		ifenq=1;
		blevel=cmd.defpri;
		break;
	case DEQ:
	#ifdef DEBUG
		printf("Execute deq!\n");
	#endif
		do_deq(cmd);
		break;
	case STAT:
	#ifdef DEBUG
		printf("Execute stat!\n");
	#endif
		do_stat(cmd);
		break;
	default:
		break;
	}
//������	
#ifdef DEBUG
	for(p=head2;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head1;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head0;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
#endif

#ifdef rundebug
	if(current)printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",current->job->pid,current->job->defpri,current->job->curpri,current->job->ownerid,current->job->wait_time,current->job->run_time);
	else printf("current=null");
	for(p=head2;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head1;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head0;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
#endif
	if(ifenq==1){
		if(current){
			if(blevel>current->job->curpri){
				sleep(10);
			#ifdef DEBUG
				printf("Select which job to run next!\n");
			#endif
				next=jobselect();
			#ifdef DEBUG
				printf("Switch to the next job!\n");
			#endif
				jobswitch();
				//printf("%d",current->job->curpri);
				if(current){
					switch(current->job->curpri){
						case 0:needruntime=current->job->run_time+5;break;
						case 1:needruntime=current->job->run_time+2;break;
						case 2:needruntime=current->job->run_time+1;break;	
						default:break;
					}
				}
			}
		}
	}
	ifenq=0;
	//sleep(0);
	//if(current)printf("%d",current->job->run_time);
	if(current){
		if(current->job->run_time>=needruntime){
			#ifdef DEBUG
				printf("Select which job to run next!\n");
			#endif
				next=jobselect();
			#ifdef DEBUG
				printf("Switch to the next job!\n");
			#endif
				jobswitch();
				//printf("%d",current->job->curpri);
				if(current){
					if(current->job->run_time==0)
					switch(current->job->curpri){
						case 0:needruntime=current->job->run_time+5;break;
						case 1:needruntime=current->job->run_time+2;break;
						case 2:needruntime=current->job->run_time+1;break;	
						default:break;
					}
					else
					switch(current->job->curpri){
						case 0:needruntime=current->job->run_time+5;break;
						case 1:needruntime=current->job->run_time+2;break;
						case 2:needruntime=current->job->run_time+1;break;	
						default:break;
					}
				}
		}
	}
	else{
	/* ѡ������ȼ���ҵ */
		#ifdef DEBUG
			printf("Select which job to run next!\n");
		#endif
		next=jobselect();
	/* ��ҵ�л� */
		#ifdef DEBUG
			printf("Switch to the next job!\n");
		#endif
		jobswitch();
		
		if(current){
			//printf("%d",current->job->curpri);
			switch(current->job->curpri){
				case 0:needruntime=current->job->run_time+5;break;
				case 1:needruntime=current->job->run_time+2;break;
				case 2:needruntime=current->job->run_time+1;break;	
				default:break;
			}
		}
	}
#ifdef rundebug
	if(current)printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",current->job->pid,current->job->defpri,current->job->curpri,current->job->ownerid,current->job->wait_time,current->job->run_time);
	else printf("current=null");
	for(p=head2;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head1;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	for(p=head0;p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
#endif
}

int allocjid()
{
	return ++jobid;
}

void updateall()
{
	struct waitqueue *p;
	struct waitqueue *beforep;
	struct waitqueue *liftp;
	/*if(current){
		switch(current->job->curpri){
			case 0: k=5;break;
			case 1: k=2;break;
			case 2: k=1;break;
			default:k=1;break;
		}
	}
	else
		k=0;*/

	/* ������ҵ����ʱ�� */
	if(current)
		current->job->run_time += 1; /* ��1����1000ms */

	/* ������ҵ�ȴ�ʱ�估���ȼ� */
	for(p = head2; p != NULL; p = p->next){
		p->job->wait_time += 1000;
	}
	for(p = head1; p != NULL; p = p->next){
		p->job->wait_time += 1000;		
		if(p->job->wait_time >= 10000 && p->job->curpri < 2){
			p->job->curpri++;
			p->job->wait_time = 0;
			for(liftp= head2; liftp!= NULL; liftp = liftp->next);
			liftp=p;
			if(p!=head1)beforep->next=p->next;
			p->next=NULL;
		}
		beforep=p;
	}
	for(p = head0; p != NULL; p = p->next){
		p->job->wait_time += 1000;		
		if(p->job->wait_time >= 10000 && p->job->curpri < 2){
			p->job->curpri++;
			p->job->wait_time = 0;
			for(liftp= head2; liftp!= NULL; liftp = liftp->next);
			liftp=p;
			if(p!=head1)beforep->next=p->next;
			p->next=NULL;
		}
		beforep=p;
	}
}

struct waitqueue* jobselect()
{
	struct waitqueue *p,*prev,*select,*selectprev;
	int highest = -1;

	select = NULL;
	selectprev = NULL;
	if(head2){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head2, p = head2; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev){
				head2 = select->next;
				select->next=NULL;
			}
	}
	else if(head1){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head1, p = head1; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev){
				head1 = select->next;
				select->next=NULL;
			}
	}
	else if(head0){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head0, p = head0; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev){
				head0 = select->next;
				select->next=NULL;
			}
	}
#ifdef DEBUG
	printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			select->job->pid,select->job->defpri,select->job->curpri,select->job->ownerid,select->job->wait_time,select->job->run_time);
#endif
	return select;
}

void jobswitch()
{
	struct waitqueue *p;
	int i;

	if(current && current->job->state == DONE){ /* ��ǰ��ҵ��� */
		/* ��ҵ��ɣ�ɾ���� */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* �ͷſռ� */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}
	

	if(next == NULL && current == NULL) /* û����ҵҪ���� */

		return;
	else if (next != NULL && current == NULL){ /* ��ʼ�µ���ҵ */

		printf("begin start new job\n");
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		waitpid(current->job->pid,NULL,0);
		kill(current->job->pid,SIGCONT);
		return;
	}
	else if (next != NULL && current != NULL){ /* �л���ҵ */
		//waitpid(current->job->pid,NULL,0);
		printf("switch to Pid: %d\n",next->job->pid);
		kill(current->job->pid,SIGSTOP);
		//current->job->curpri = current->job->defpri;
		current->job->wait_time = 0;
		current->job->state = READY;

		/* �Żصȴ����� */
		if(current->job->curpri==2){
			current->job->curpri = 1;
			if(head1){
				for(p = head1; p->next != NULL; p = p->next);
				p->next = current;
			}else
				head1=current;
		}else if(current->job->curpri==1){
			current->job->curpri = 0;
			if(head0){
				for(p = head0; p->next != NULL; p = p->next);
				p->next = current;
			}else
				head0=current;
		}else if(current->job->curpri ==0){
			if(head0){
				for(p = head0; p->next != NULL; p = p->next);
				p->next = current;
			}else
				head0=current;
		}
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		current->job->wait_time = 0;
		//sleep(5);
		//waitpid(current->job->pid,NULL,0);
		kill(current->job->pid,SIGCONT);//���̺�pid info��Ϣ sig �ź�
		return;
	}else{ /* next == NULL��current != NULL�����л� */
		return;
	}
}

void sig_handler(int sig,siginfo_t *info,void *notused)
{
	int status;
	int ret;

	switch (sig) {
case SIGVTALRM: /* �����ʱ�������õļ�ʱ��� */
	scheduler();
	#ifdef DEBUG
		printf("SIGVTALRM RECEIVED!\n");
	#endif
	return;
case SIGCHLD: /* �ӽ��̽���ʱ���͸������̵��ź� */
	ret = waitpid(-1,&status,WNOHANG);//pid=-1ʱ���ȴ��κ�һ���ӽ����˳���û���κ����ƣ���ʱwaitpid��wait������һģһ����
	if (ret == 0)
		return;
	if(WIFEXITED(status)){//wifexited   WIFEXITED(status)����ӽ�������������Ϊ��0ֵ
		if(current->job->run_time>0){
			current->job->state = DONE;
			printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
		}
		else{
		
			current->job->state = READY;
			printf("beacse of time over,wait getting more time by CPU");
		}
	}else if (WIFSIGNALED(status)){//WIFSIGNALED(status)����ӽ�������Ϊ�źŶ�������˺�ֵΪ��
		printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
	}else if (WIFSTOPPED(status)){//WIFSTOPPED(status)����ӽ��̴�����ִͣ�������˺�ֵΪ�档һ��ֻ��ʹ��WUNTRACED ʱ�Ż��д������
		printf("child stopped, signal number = %d\n",WSTOPSIG(status));
	}
	return;
	default:
		return;
	}
}

void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd)
{
	struct waitqueue *newnode,*p;//���нṹ��job.h�ﶨ��
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;

	sigemptyset(&zeromask);

	/* ��װjobinfo���ݽṹ */
	newjob = (struct jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();
	newjob->defpri = enqcmd.defpri;
	newjob->curpri = enqcmd.defpri;
	newjob->ownerid = enqcmd.owner;
	newjob->state = READY;
	newjob->create_time = time(NULL);
	newjob->wait_time = 0;
	newjob->run_time = 0;
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));
	newjob->cmdarg = arglist;
	offset = enqcmd.data;
	argvec = enqcmd.data;
	while (i < enqcmd.argnum){
		if(*offset == ':'){
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;

#ifdef DEBUG

	printf("enqcmd argnum %d\n",enqcmd.argnum);
	for(i = 0;i < enqcmd.argnum; i++)
		printf("parse enqcmd:%s\n",arglist[i]);

#endif

	/*��ȴ������������µ���ҵ*/
	newnode = (struct waitqueue*)malloc(sizeof(struct waitqueue));
	newnode->next =NULL;
	newnode->job=newjob;

	if(newjob->curpri==2)
	{
		if(head2){
			for(p=head2;p->next != NULL; p=p->next);
			p->next =newnode;
		}else
		head2=newnode;
	}
	else if(newjob->curpri==1)
	{
		if(head1){
			for(p=head1;p->next != NULL; p=p->next);
			p->next =newnode;
		}else
		head1=newnode;
	}
	else if(newjob->curpri==0)
	{
		if(head0){
			for(p=head0;p->next != NULL; p=p->next);
			p->next =newnode;
		}else
		head0=newnode;
		
	}
	/*Ϊ��ҵ��������*/
	//signal(SIGUSR1, setGoon);
	if((pid=fork())<0)
		error_sys("enq fork failed");
	

	if(pid==0){////////////////////////////////////////////////////////////////////�����⣬��Ϊ�ӽ��̵�pid==0�������������̲�������
		//newjob->pid =getpid();
                //while(goon == 0) ;
                //goon = 0;
		//kill(pid, SIGUSR1);
                
		/*�����ӽ���,�ȵ�ִ��*/
		raise(SIGSTOP);//SIGSTOP�ṩ������Ա��ͣ���̵���Ȩ�� ���Բ��ܺ��Ժ��ض��塣���û�����CTRL-Zʱ�� ��ǰ̨�����鷢��SIGTSTP�ź�����ͣ���̣�Ĭ�϶������� ���źſ��Ա����Ժ��ض��塣
#ifdef DEBUG

		printf("begin running\n");
		for(i=0;arglist[i]!=NULL;i++)
			printf("arglist %s\n",arglist[i]);
#endif

		/*�����ļ�����������׼���*/
		dup2(globalfd,1);
		/* ִ������ */
		if(execv(arglist[0],arglist)<0)
			printf("exec failed\n");
		exit(1);
	}else{
		//kill(pid, SIGUSR1);
                //while(goon == 0) ;
                //goon = 0;
                //printf("2\n");
		newjob->pid=pid;
		//waitpid(pid,NULL,0);
	}
}

void do_deq(struct jobcmd deqcmd)
{
	int deqid,i;
	struct waitqueue *p=NULL,*prev=NULL,*select=NULL,*selectprev=NULL;
	deqid=atoi(deqcmd.data);

#ifdef DEBUG
	printf("deq jid %d\n",deqid);
#endif

	/*current jodid==deqid,��ֹ��ǰ��ҵ*/
	if (current && current->job->jid ==deqid){
		printf("teminate current job\n");
		kill(current->job->pid,SIGKILL);
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{ /* �����ڵȴ������в���deqid */
		select=NULL;
		selectprev=NULL;
		if(head2){
			for(prev=head2,p=head2;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
				selectprev->next=select->next;
				if(select==selectprev){
					head2 = select->next;
					select->next=NULL;
				}
		}
		if(head1){
			for(prev=head1,p=head1;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
				selectprev->next=select->next;
				if(select==selectprev){
					head1 = select->next;
					select->next=NULL;
				}
		}
		if(head0){
			for(prev=head0,p=head0;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
				selectprev->next=select->next;
				if(select==selectprev){
					head0 = select->next;
					select->next=NULL;
				}
		}
		if(select){
			for(i=0;(select->job->cmdarg)[i]!=NULL;i++){
				free((select->job->cmdarg)[i]);
				(select->job->cmdarg)[i]=NULL;
			}
			free(select->job->cmdarg);
			free(select->job);
			free(select);
			select=NULL;
		}
	}
}

void do_stat(struct jobcmd statcmd)
{
	struct waitqueue *p;
	char timebuf[BUFLEN];
	
	FILE *fp;
	//sleep(5);
	if((fp=fopen(FIFO,"w"))==NULL){
		perror("open");
	}
	/*
	*��ӡ������ҵ��ͳ����Ϣ:
	*1.��ҵID
	*2.����ID
	*3.��ҵ������
	*4.��ҵ����ʱ��
	*5.��ҵ�ȴ�ʱ��
	*6.��ҵ����ʱ��
	*7.��ҵ״̬
	*/

	/* ��ӡ��Ϣͷ�� */
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if(current){
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
		fprintf(fp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
	}

	for(p=head2;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		fprintf(fp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
	}
	for(p=head1;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		fprintf(fp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
	}
	for(p=head0;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		fprintf(fp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
	}
	fclose(fp);
}

int main()
{
	struct timeval interval;
	struct itimerval new,old;
	struct stat statbuf;
	struct sigaction newact,oldact1,oldact2;
	
	
#ifdef DEBUG
	printf("DEBUG IS OPEN");
#endif


	if(stat("/tmp/server",&statbuf)==0){
		/* ���FIFO�ļ�����,ɾ�� */
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/server",0666)<0)
		error_sys("mkfifo failed");
	/* �ڷ�����ģʽ�´�FIFO */
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)
		error_sys("open fifo failed");

	/* �����źŴ������� */
	newact.sa_sigaction=sig_handler;
	sigemptyset(&newact.sa_mask);
	newact.sa_flags=SA_SIGINFO;
	sigaction(SIGCHLD,&newact,&oldact1);
	sigaction(SIGVTALRM,&newact,&oldact2);

	/* ����ʱ����Ϊ1000���� */
	interval.tv_sec=1;
	interval.tv_usec=0;

	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);

	while(siginfo==1);

	close(fifo);
	close(globalfd);
	return 0;
}
