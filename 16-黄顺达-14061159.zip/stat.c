#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"

#define FIFO "MYFIFO"
/* 
 * �����﷨��ʽ
 *     stat
 */
void usage()
{
	printf("Usage: stat\n");		
}

int main(int argc,char *argv[])
{
	struct jobcmd statcmd;
	int fd;
FILE *fp;
char buf[200];

	if(argc!=1)
	{
		usage();
		return 1;
	}

	statcmd.type=STAT;
	statcmd.defpri=0;
	statcmd.owner=getuid();
	statcmd.argnum=0;

	if((fd=open("/tmp/server",O_WRONLY))<0)
		error_sys("stat open fifo failed");

	if(write(fd,&statcmd,DATALEN)<0)
		error_sys("stat write failed");


if(mkfifo(FIFO,S_IFIFO|0666)<0) {
}
 	
	fp=fopen(FIFO,"r");
	while(fgets(buf,sizeof(buf),fp)!=NULL){
	printf("%s",buf);
	}
	fclose(fp);

	close(fd);
	return 0;
}
