#ifndef JOB_H
#define JOB_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <signal.h>
#include <sys/types.h>

#ifndef DEBUG
#define DEBUG
#endif

#undef DEBUG

#define BUFLEN 100
#define GLOBALFILE "screendump"

enum jobstate{
    READY,RUNNING,DONE
};

enum cmdtype{
    ENQ=-1,DEQ=-2,STAT=-3 
};
struct jobcmd{
    enum cmdtype type;      /*命令的种类*/
    int argnum;         /*参数个数*/
    int owner;          /*所属用户*/
    int defpri;         /*默认优先级*/
    char data[BUFLEN];          /*参数*/
};

#define DATALEN sizeof(struct jobcmd)

struct jobinfo{
    int jid;              /* 作业ID */
    int pid;              /* 进程ID */
    char** cmdarg;        /* 命令参数 */
    int defpri;           /* 默认优先级 */
    int curpri;           /* 当前优先级 */
    int ownerid;          /* 作业所有者ID */
    int wait_time;        /* 作业在等待队列中等待时间 */
    time_t create_time;   /* 作业创建时间 */
    int run_time;         /* 作业运行时间 */
    enum jobstate state;  /* 作业状态 */
};

struct waitqueue{
    struct waitqueue *next;
    struct jobinfo *job;
};

void scheduler();               //调度函数
void sig_handler(int sig,siginfo_t *info,void *notused);            //信号处理函数
int allocjid();                                                                                 //申请作业ID
void add_queue(struct jobinfo *job);                                          //添加一个作业
void del_queue(struct jobinfo *job);                                            //删除一个作业
void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd);      //向队列增加一个作业
void do_deq(struct jobcmd deqcmd);                                              //从队列移除一个作业
void do_stat(struct jobcmd statcmd);                                                //打印某一作业信息
void updateall();                                                                                   //更新函数
struct waitqueue* jobselect();                                                              //作业选择函数
void jobswitch();                                                                               //作业切换函数
void putback_queue(struct waitqueue *w,int pri);                                           //将节点放回队列中
void change_timeternal(struct waitqueue *w);                                       //更改时间片

void error_doit(int errnoflag,const char *fmt,va_list ap);                  //错误处理函数
void error_sys(const char *fmt,...);                                                   
void error_msg(const char *fmt,...);
void error_quit(const char *fmt,...);

#endif

