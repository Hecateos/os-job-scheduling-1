#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"
#define DEBUG
/* 
 * 命令语法格式
 *     enq [-p num] e_file args
 */
 //打印该函数使用帮助
void usage()
{
	printf("Usage: enq[-p num] e_file args\n"
		"\t-p num\t\t specify the job priority\n"
		"\te_file\t\t the absolute path of the exefile\n"
		"\targs\t\t the args passed to the e_file\n");
}

int main(int argc,char *argv[])
{
	int p=1;
	int fd;
	char c,*offset;
	struct jobcmd enqcmd;

	//只有./enq一个参数时
	if(argc==1){
		usage();
		return 1;
	}
	//printf("###1###\n");
	//当还有参数时，移动参数列表指针
	while(--argc>0 && (*++argv)[0]=='-'){
		while(c=*++argv[0]){
			switch(c)
			{
								//第一个参数-p
				case 'p':p=atoi(*(++argv));
					argc--;
					break;
				default:
					printf("Illegal option %c\n",c);
					return 1;
			}
		}
	}
	//printf("###2###\n");
	if(p<0||p>3)
	{
		printf("invalid priority:must between 0 and 3\n");
		return 1;
	}

	enqcmd.type=ENQ;
	enqcmd.defpri=p;
	enqcmd.owner=getuid();	//作业发出者为用户id
	enqcmd.argnum=argc;		//此时作业内部的命令参数列表的个数为除去./enq [-p num]的个数
	offset=enqcmd.data;		//得到作业中命令的参数列表？？？？？？？
	//printf("###3###%s\n",enqcmd.data);
	while (argc-->0)			//存到命令结构体中，参数用冒号连接起来
	{
		strcpy(offset,*argv);	
		strcat(offset,":");
		offset=offset+strlen(*argv)+1;
		argv++;
	}
	///printf("###3###%s\n",enqcmd.data);

    #ifdef DEBUG
		printf("enqcmd cmdtype\t%d\n"
			"enqcmd owner\t%d\n"
			"enqcmd defpri\t%d\n"
			"enqcmd data\t%s\n",
			enqcmd.type,enqcmd.owner,enqcmd.defpri,enqcmd.data);

    #endif 
		//printf("###4###\n");
		if((fd=open("/tmp/server",O_WRONLY))<0)	//通过命名管道写入命令
			error_sys("enq open fifo failed");

		if(write(fd,&enqcmd,DATALEN)<0)
			error_sys("enq write failed");

		//printf("###5###\n");
		close(fd);
		return 0;
}

