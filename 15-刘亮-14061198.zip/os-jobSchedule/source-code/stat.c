#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"

/* 
 * 命令语法格式
 *     stat
 */
void usage()
{
	printf("Usage: stat\n");		
}

int main(int argc,char *argv[])
{
	struct jobcmd statcmd;
	struct stat statbuf1;
	int fd;
	int fifo_stat;
	int fd_read;
	char string[1024];

	//只有./stat
	if(argc!=1)
	{
		usage();
		return 1;
	}
	//优先级为1
	statcmd.type=STAT;
	statcmd.defpri=0;
	statcmd.owner=getuid();
	statcmd.argnum=0;
	statcmd.data[0]='\0';
	//建立管道传递信息
	if(stat("statbuffer",&statbuf1)==0){
		if(remove("statbuffer")<0)
			error_sys("remove falied");
	}
	if(mkfifo("statbuffer",0666)<0)
		error_sys("mkfifo failed");

	if((fd=open("/tmp/server",O_WRONLY))<0)	//打开命名管道写入命令
		error_sys("stat open fifo failed");

	if(write(fd,&statcmd,DATALEN)<0)
		error_sys("stat write failed");

	close(fd);
	
	//打开打印信息管道读
	if((fifo_stat=open("statbuffer",O_RDONLY))<0)//需要读阻塞！！！
		error_sys("open fifo_stat failed");
	if((fd_read=read(fifo_stat,string,1024))<0)		//从文件描述符fifo读入，从命名管道读入cmd
		error_sys("read fifo failed");
	if(fd_read){
		printf("%s",string);//打印作业的类型，优先级，参数
	}
	close(fifo_stat);

	return 0;
}
