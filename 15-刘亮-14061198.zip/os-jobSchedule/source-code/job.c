#include <stdio.h>
	#include <unistd.h>
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <sys/time.h>
	#include <sys/wait.h>
	#include <string.h>
	#include <signal.h>
	#include <fcntl.h>
	#include <time.h>
	#include "job.h"
	int jobid=0;	
	int siginfo=1;
	int fifo;
	int fifo_stat;
	int globalfd;
	int timeteranl=1;
	int timeenv=0;

	struct waitqueue *head_high=NULL;
	struct waitqueue *head_mid=NULL;
	struct waitqueue *head_low=NULL;
	struct waitqueue *head=NULL;
	struct waitqueue *next=NULL,*current =NULL;

/* 调度程序 */
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	int  count = 0;
	bzero(&cmd,DATALEN);				//初始化cmd 前DATALEN个字节置0
	if((count=read(fifo,&cmd,DATALEN))<0)		//从文件描述符fifo读入，从命名管道读入cmd
		error_sys("read fifo failed");
	if(count){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);//打印作业的类型，优先级，参数
	}

	/* 更新等待队列中的作业 */
	updateall();
	switch(cmd.type){		//判断程序类型
	case ENQ:			//执行相应的命令./enq ./deq ./stat	
		do_enq(newjob,cmd);
		break;
	case DEQ:
		do_deq(cmd);
		break;
	case STAT:
		do_stat(cmd);
		break;
	default:
		break;
	}
	/* 选择高优先级作业 */
	//next=jobselect();
	/* 作业切换 */
	if((timeenv>=timeteranl)){
		//printf("time pie end\n");
		next=jobselect();
		jobswitch();
		timeenv=0;
	}
	/*else if(current==NULL){
		jobswitch();
	}*/

}

//申请一个作业，返回作业id
int allocjid()
	{
	return ++jobid;
}

//更新运行作业运行时间，就绪作业等待时间，并且适当调整优先级
void updateall()
{
	struct waitqueue *p;
	struct waitqueue *pre;
	struct waitqueue *q;
	int flag = 0;	//标记是否取到可以改变优先级的元素
	//struct waitqueue *r;

	/* 更新作业运行时间 */
	if(current)		//若当前有作业正在运行，其运行时间加1
		current->job->run_time += 1; /* 加1代表1000ms */
	/* 更新作业等待时间及优先级 */
	for(p = head_high; p != NULL; p = p->next){
		p->job->wait_time += 1000;
	}
	for(pre = head_mid,p = head_mid; p != NULL;){
		p->job->wait_time += 1000;
		if(p->job->wait_time > 10000 && p->job->curpri < 3){//若有作业等待时间大于5s且优先级低于3，则提高其优先级
			flag++;
			p->job->curpri++;
			p->job->wait_time = 0;
			if(pre==p){				//将低优先级队列中元素拿到高优先级队列中去
				flag++;
				head_mid = p->next;		//取到第一个元素
			}
			else{
				pre->next = p->next;		
			}
			p->next = NULL;
			if(head_high!=NULL){
				for(q=head_high;q->next!=NULL;q=q->next);	//高优先级队列中没有元素时充当队首
				q->next = p;
			}
			else{
				head_high=p;
			}
		}
		//取到队头元素改变队列
		if(flag==2){
			pre = head_mid;
			p = head_mid;
			flag = 0;
		}
		//取到非队头元素
		else if(flag==1){
			p = pre->next;
			flag = 0;
		}
		//未取到元素
		else{
			pre = p;
			p = p->next;
			flag = 0;
		}
	}
	for(pre = head_low,p = head_low; p != NULL;){
		p->job->wait_time += 1000;
		if(p->job->wait_time > 10000 && p->job->curpri < 3){//若有作业等待时间大于5s且优先级低于3，则提高其优先级
			flag ++;
			p->job->curpri++;
			p->job->wait_time = 0;
			if(pre==p){
				flag++;
				head_low = p->next;
			}
			else{
				pre->next = p->next;
			}
			p->next = NULL;
			if(head_mid!=NULL){
				for(q=head_mid;q->next!=NULL;q=q->next);
				q->next = p;
			}
			else{
				head_mid=p;
			}			
		}
		if(flag==2){
			pre = head_low;
			p = head_low;
			flag = 0;
		}
		else if(flag==1){
			p = pre->next;
			flag = 0;
		}
		else{
			pre = p;
			p = p->next;
			flag = 0;
		}
	}
}

//依照优先级先后找到优先级最高的作业
struct waitqueue* jobselect()
{
	struct waitqueue *select;
	select = NULL;
	if(head_high){
		select = head_high;
		head_high = head_high->next;
		select->next = NULL;
		return select;
	}
	else if(head_mid){
		select = head_mid;
		head_mid = head_mid->next;
		select->next = NULL;
		return select;
	}
	else if(head_low){
		select = head_low;
		head_low = head_low->next;
		select->next = NULL;
		return select;
	}
	else{
		return select;
	}
}

//作业切换函数，时间片到达，则切换current为next
void jobswitch()
{
	//struct waitqueue *p;
	int i;

	if(current && current->job->state == DONE){ /* 当前作业完成 */
		/* 作业完成，删除它 */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* 释放空间 */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}

	if(next == NULL && current == NULL){ /* 没有作业要运行 */
		timeteranl=1;
		//printf("set timeteranl to 1\n");
		return;
	}
	else if (next != NULL && current == NULL){ // 开始新的作业 

		printf("begin start new job jid: %d curpri: %d\n",next->job->jid,next->job->curpri);
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		change_timeternal(current);
		//current->job->curpri=current->job->defpri;
		current->job->wait_time=0;
		//printf("change timeteranl to %d\n",timeteranl );
		kill(current->job->pid,SIGCONT);//向当前要运行的作业发送信号SIGCONT，要等到子进程进行到raise(SIGSTOP)之后再发送信号
		return;
	}
	else if (next != NULL && current != NULL){ /* 切换作业 */

		if(next->job->curpri>=current->job->curpri){
			printf("switch to jid: %d curpri: %d\n",next->job->jid,next->job->curpri);
			kill(current->job->pid,SIGSTOP);	//向当前正在运行的作业发送信号SIGSTOP
			if(current->job->run_time>=10 && current->job->curpri>current->job->defpri){
				current->job->curpri = current->job->curpri - 1;	//当前作业优先级为初始优先级
				current->job->run_time = 0;
			}
			current->job->wait_time = 0;		//重置当前作业等待时间
			current->job->state = READY;		//状态改为就绪状态
			current->next = NULL;			//放回时没有将其后连接的变为空
			/* 放回等待队列 */
			putback_queue(current,current->job->curpri);
			current = next;
			next = NULL;
			current->job->state = RUNNING;	//改变作业状态为运行
			change_timeternal(current);
			//printf("change timeteranl to %d\n",timeteranl );
			current->job->wait_time = 0;		//等待时间变为0
			kill(current->job->pid,SIGCONT);	//向当前要运行的作业发送SIGCONT信号
		}
		else{	
			next->next = NULL;
			putback_queue(next,next->job->curpri);
		}
		return;
	}else if(current!=NULL && next==NULL){
		change_timeternal(current);
		//printf("change timeteranl to %d\n",timeteranl );
	}
	else{ /* next == NULL且current != NULL，不切换 */
		return;
	}
}

//信号处理函数，在切换作业时用到
void sig_handler(int sig,siginfo_t *info,void *notused)
{
	int status;
	int ret;

	switch (sig) {
		case SIGVTALRM: /* 到达计时器所设置的计时间隔 */
			//printf("alarm\n");
			timeenv++;
			scheduler();
			return;
		case SIGCHLD: /* 子进程结束时传送给父进程的信号 */
			ret = waitpid(-1,&status,WNOHANG);		//pid=-1 等待任何子进程  WNOHANG如果没有任何已经结束的子进程则马上返回
			if (ret == 0)
				return;
			if(WIFEXITED(status)){			//子进程正常结束
				current->job->state = DONE;
				printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
			}else if (WIFSIGNALED(status)){		//子进程因为信号而结束
				printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
			}else if (WIFSTOPPED(status)){		//子进程处于暂停情况
				printf("child stopped, signal number = %d\n",WSTOPSIG(status));
			}
			return;
		default:
			return;
	}
}

//向队列中加入作业的函数
void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd)
{
	struct waitqueue *newnode;
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;
	int violate_flag = 0;//抢占信号

	sigemptyset(&zeromask);	//将参数set信号集初始化并清空。

	/* 封装jobinfo数据结构 */
	newjob = (struct jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();			//给新作业一个作业id
	newjob->defpri = enqcmd.defpri;	//新作业默认优先级设置
	newjob->curpri = enqcmd.defpri;	//作业优先级初始化
	newjob->ownerid = enqcmd.owner;	//作业提交者
	newjob->state = READY;		//作业初始状态为就绪
	newjob->create_time = time(NULL);	//创建时间为当前系统时间，从1970年以来的秒数
	newjob->wait_time = 0;			//初始等待时间
	newjob->run_time = 0;			//作业运行时间
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));	//作业从输入命令获取命令参数列表
	newjob->cmdarg = arglist;			
	offset = enqcmd.data;			//作业命令的参数，首地址
	argvec = enqcmd.data;			
	while (i < enqcmd.argnum){		//将命令参数赋给作业
		if(*offset == ':'){			//以冒号分割获得参数列表
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;		//参数列表结束标志

	/*向等待队列中增加新的作业*/
	newnode = (struct waitqueue*)malloc(sizeof(struct waitqueue));
	newnode->next =NULL;
	newnode->job=newjob;

		if(current!=NULL && newnode->job->curpri>current->job->curpri){
			violate_flag = 1;
			printf("add job jid: %d curpri: %d start!\n",newnode->job->jid,newnode->job->curpri);
			kill(current->job->pid,SIGSTOP);	//向当前正在运行的作业发送信号SIGSTOP
			current->job->wait_time = 0;		//重置当前作业等待时间
			current->job->state = READY;		//状态改为就绪状态
			current->next = NULL;			//放回时没有将其后连接的变为空
			/* 放回等待队列 */
			putback_queue(current,current->job->curpri);
			current = newnode;
		}
		else if(current==NULL){
			violate_flag = 1;
			current = newnode;
		}else{
			putback_queue(newnode,newnode->job->curpri);
		}

	/*为作业创建进程*/
	if((pid=fork())<0)
		error_sys("enq fork failed");

	if(pid==0){
		newjob->pid =getpid();
		/*阻塞子进程,等等执行*/
		if(violate_flag==0){	//若无法抢占
			raise(SIGSTOP);			//向自己发送暂停信号
		}

		/*复制文件描述符到标准输出*/
		dup2(globalfd,1);
		/* 执行命令 */
		if(execv(arglist[0],arglist)<0)
			printf("exec failed\n");
		exit(1);

	}else{
		newjob->pid=pid;
	}
}

void do_deq(struct jobcmd deqcmd)
{
	int deqid,i;
	struct waitqueue *p,*prev,*select,*selectprev;
	deqid=atoi(deqcmd.data);			//把字符串转换成整型数,得到删除作业的id ，deq 的参数为作业号。。。

	/*current jodid==deqid,终止当前作业*/
	if (current && current->job->jid ==deqid){
		printf("teminate current job\n");
		kill(current->job->pid,SIGKILL);		//结束正在运行的作业
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){//释放资源
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{ /* 或者在等待队列中查找deqid */
		select=NULL;
		selectprev=NULL;
		if(head_high){
			for(prev=head_high,p=head_high;p!=NULL;prev=p,p=p->next){
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
			}
			if(select!=NULL){
				if(select==selectprev){
					head_high=selectprev->next;//当选取的job为第一个时且后续还有作业时发生bug
				}
				else{
					selectprev->next=select->next;
				}
			}
		}
		if(head_mid!=NULL && select==NULL){
			for(prev=head_mid,p=head_mid;p!=NULL;prev=p,p=p->next){
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
			}
			if(select!=NULL){
				if(select==selectprev){
					head_mid=selectprev->next;//当选取的job为第一个时且后续还有作业时发生bug
				}
				else{
					selectprev->next=select->next;
				}
			}
		}
		if(head_low!=NULL && select==NULL){
			for(prev=head_low,p=head_low;p!=NULL;prev=p,p=p->next){
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
			}
			if(select!=NULL){
				if(select==selectprev){
					head_low=selectprev->next;//当选取的job为第一个时且后续还有作业时发生bug
				}
				else{
					selectprev->next=select->next;
				}
			}
		}
		if(select){
			for(i=0;(select->job->cmdarg)[i]!=NULL;i++){//释放资源
				free((select->job->cmdarg)[i]);
				(select->job->cmdarg)[i]=NULL;
			}
			free(select->job->cmdarg);
			free(select->job);
			free(select);
			select=NULL;
		}
	}
}

void do_stat(struct jobcmd statcmd)
{
	struct waitqueue *p;
	char timebuf[BUFLEN];
	char string[1024];
	char temp[1024];
	int fd_write;
	string[0]='\0';
	temp[0]='\0';
	/*
	*打印所有作业的统计信息:
	*1.作业ID
	*2.进程ID
	*3.作业所有者
	*4.作业运行时间
	*5.作业等待时间
	*6.作业创建时间
	*7.作业状态
	*/

	/* 打印信息头部 */
	strcat(temp,"JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCURPRI\tSTATE\n");
	printf("%s", temp);
	strcat(string,temp);
	temp[0]='\0';
	if(current){
		strcpy(timebuf,ctime(&(current->job->create_time)));	//ctime最后一次改变文件或目录(改变的是原数据即:属性)的时间
		timebuf[strlen(timebuf)-1]='\0';
		sprintf(temp,"%d\t%d\t%d\t%d\t%d\t\t%d\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			current->job->curpri,
			"RUNNING");
		printf("%s",temp);
		strcat(string,temp);
		temp[0]='\0';
	}
	strcat(temp,"*********************high***********************************\n");
	printf("%s",temp );
	strcat(string,temp);
	temp[0]='\0';
	for(p=head_high;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		sprintf(temp,"%d\t%d\t%d\t%d\t%d\t\t%d\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			p->job->curpri,
			"READY");
		printf("%s",temp);
		strcat(string,temp);
		temp[0]='\0';
	}
	strcat(temp,"*********************mid************************************\n");
	printf("%s",temp );
	strcat(string,temp);
	temp[0]='\0';
	for(p=head_mid;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		sprintf(temp,"%d\t%d\t%d\t%d\t%d\t\t%d\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			p->job->curpri,
			"READY");
		printf("%s", temp);
		strcat(string,temp);
		temp[0]='\0';
	}
	strcat(temp,"*********************low************************************\n");
	printf("%s",temp );
	strcat(string,temp);
	temp[0]='\0';
	for(p=head_low;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		sprintf(temp,"%d\t%d\t%d\t%d\t%d\t\t%d\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			p->job->curpri,
			"READY");
		printf("%s",temp );
		strcat(string,temp);
		temp[0]='\0';
	}
	strcat(temp,"************************************************************\n");
	printf("%s",temp );
	strcat(string,temp);
	temp[0]='\0';
	//通过管道写回./stat程序
	if((fifo_stat=open("statbuffer",O_WRONLY|O_NONBLOCK))<0)//此处以非阻塞方式或者阻塞方式写都可
		error_sys("open fifo_stat failed");
	if((fd_write =write(fifo_stat,string,sizeof(string)))<0)
		error_sys("job write failed");
	close(fifo_stat);
}

void putback_queue(struct waitqueue *w,int pri){
	struct waitqueue *p;
	switch(pri){
		case 3:		
			if(head_high!=NULL){	
				for(p = head_high; p->next!= NULL; p = p->next);
				p->next = w;			
			}
			else{
				head_high = w;
			}

			break;
		case 2:		
			if(head_mid!=NULL){	
				for(p = head_mid; p->next != NULL; p = p->next);
				p->next = w;			
			}
			else{
				head_mid = w;
			}
			break;		
		case 1:	
			if(head_low!=NULL){		
				for(p = head_low; p->next != NULL; p = p->next);
				p->next = w;			
			}
			else{
				head_low = w;
			}
			break;
		default:
			break;
			}
}

void change_timeternal(struct  waitqueue *w){
	switch(w->job->curpri){//改变当前时间片为对应需要执行作业的优先级
		case 1:timeteranl=5;
			break;
		case 2:timeteranl=2;
			break;
		case 3:timeteranl=1;
			break;
		default:
			break;
	}
}

int main()
{
	struct timeval interval;
	struct itimerval new,old;
	struct stat statbuf;
	struct sigaction newact,oldact1,oldact2;
	//任务加入管道
	if(stat("/tmp/server",&statbuf)==0){		//通过文件名filename获取文件信息，这里是获取命名管道的信息，并保存在buf所指的结构体stat中，若已经存在命名管道，删掉

		/* 如果FIFO文件存在,删掉 */
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/server",0666)<0)	//创建命名管道  默认情况下,创建的FIFO的模式为0666('a+rw')减去umask中设置的位.  k
		error_sys("mkfifo failed");

	/* 在非阻塞模式下打开FIFO */
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)
		error_sys("open fifo failed");

	/* 建立信号处理函数 */
	newact.sa_sigaction=sig_handler;	//连接处理函数
	sigemptyset(&newact.sa_mask);	//将要屏蔽的信号集清空
	newact.sa_flags=SA_SIGINFO;		//信号附带的参数可以传到信号处理函数之中
	sigaction(SIGCHLD,&newact,&oldact1);		//指定要处理的信号，指向newact
	sigaction(SIGVTALRM,&newact,&oldact2);

	/* 设置时间间隔为1000毫秒 */
	interval.tv_sec=1;
	interval.tv_usec=0;

	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);//虚拟时间，每间隔1s钟发一次闹钟

	while(siginfo==1);

	close(fifo);
	close(globalfd);
	return 0;
}


/*
		大概框架：主函数创建命名管道，供作业的写入与读取；
		主函数设定定时器，每隔1s时间片到达，重新调度一个作业scheduler()；
		scheduler()通过优先级找到即将要执行的作业jobselect();
		scheduler()在找到作业后切换作业jobswitch();
		作业执行函数三个
			do_enq():传入的第一个参数似乎没有意义，第二个参数作为作业的命令信息传入增加作业节点，添加作业时阻塞作业子进程运行
			deq():传入命令信息，根据命令参数找到对应作业号删除作业节点
			stat():传入参数似乎也没有意义，打印当前所有作业的状态

		注意：作业的DONE标志由子进程正常结束发送给父进程的信号SIGCHLD知道
		该源码大概实现了简单轮转调度的算法，时间片为1

*/