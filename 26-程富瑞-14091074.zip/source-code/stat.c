#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"

/* 
 * �����﷨��ʽ
 *     stat
 */
void usage()
{
	printf("Usage: stat\n");		
}

int main(int argc,char *argv[])
{
	struct jobcmd statcmd;
	int fd;
	int fifo2;
	int count=0;
	struct stat statbuf;
	char string0[10000];
	if(argc!=1)
	{
		usage();
		return 1;
	}

	statcmd.type=STAT;
	statcmd.defpri=0;
	statcmd.owner=getuid();
	statcmd.argnum=0;
#ifdef DEBUG
	printf("statcmd cmdtype\t%d(-1 means ENQ, -2 means DEQ, -3 means STAT)\n"
		"statcmd owner\t%d\n"
		"statcmd defpri\t%d\n",
		statcmd.type,statcmd.owner,statcmd.defpri);
#endif 
	if((fd=open("/tmp/server",O_WRONLY))<0)
		error_sys("stat open fifo failed");

	if(write(fd,&statcmd,DATALEN)<0)
		error_sys("stat write failed");
	if(stat("/tmp/server2",&statbuf)==0){
		if(remove("/tmp/server2")<0){
			error_sys("remove /tmp/server2 failed");
		}
	}

	if(mkfifo("/tmp/server2",0666)<0){
		error_sys("mkfifo2 failed");
	}
	if((fifo2=open("/tmp/server2",O_RDONLY))<0){
		error_sys("open fifo2 failed");
	}
	if((count=read(fifo2,string0,10000))<0){
		error_sys("read fifo2 failed");
	}
	puts(string0);
	close(fd);
	return 0;
}
