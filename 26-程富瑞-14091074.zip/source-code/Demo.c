#include "time.h"
#include <stdio.h>

void main()
{
  time_t timer,timerc;
  int count=1;  
  struct tm *timeinfo;
  time(&timer);//系统开始的时间
  while(count < 10000)
  {
     time(&timerc);
     if((timerc-timer)>=1)//每过1秒打印
     {
       printf("The program is running for %ds\n",count++);
       timer=timerc;
     }
  }
  
}
