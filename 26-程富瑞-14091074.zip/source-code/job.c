#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include "job.h"
//#define DEBUG
int jobid=0;
int siginfo=1;
int fifo;
int globalfd;
int counter = 0;
struct waitqueue *LV1_head=NULL,*LV2_head=NULL,*LV3_head=NULL;
struct waitqueue *next=NULL,*current =NULL;

/* ���ȳ��� */
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	struct waitqueue *p;
	int  count = 0;
	bzero(&cmd,DATALEN);
	if((count=read(fifo,&cmd,DATALEN))<0)
		error_sys("read fifo failed");
#ifdef DEBUG

	if(count){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s////\n",cmd.type,cmd.defpri,cmd.data);
	}
#endif

	/* ���µȴ������е���ҵ */
#ifdef DEBUG
	printf("Update jobs in wait queue!\n");
	printf("Before update:\n");
	printimformation();
#endif
	updateall();
#ifdef DEBUG
	printf("After update:\n");
	printimformation();
#endif
	counter++;
#ifdef DEBUG
	printf("Before execute commond:\n");
	printimformation();
#endif
	switch(cmd.type){
	case ENQ:
		do_enq(newjob,cmd);
		break;
	case DEQ:
		do_deq(cmd);
		break;
	case STAT:
		do_stat(cmd);
		break;
	default:
		break;
	}
#ifdef DEBUG
	printf("After execute commond:\n");
	printimformation();
#endif	
	/* ѡ������ȼ���ҵ */
#ifdef DEBUG
	printf("Select which job to do next!\n");
#endif
	if(next == NULL)
		next=jobselect();
#ifdef DEBUG
	if(next){
		printf("The selected job's imformation:\n");
		printf("job's jid\t%d\n"
			"job's pid\t%d\n"
			"job's ownerid\t%d\n"
			"job's run_time\t%d\n"
			"job's waiting_time\t%d\n",
			next->job->jid,
			next->job->pid,
			next->job->ownerid,
			next->job->run_time,		
			next->job->wait_time);
	}
#endif
	/* ��ҵ�л� */
#ifdef DEBUG
	printf("Switch to the next job!\n");
	printf("Before switch:\n");
	printimformation();
#endif
	jobswitch();
#ifdef DEBUG
	printf("After switch:\n");
	printimformation();
#endif
}

int allocjid()
{
	return ++jobid;
}

void updateall()
{
	struct waitqueue *p,*prev,*q;
	
	/* ������ҵ����ʱ�� */
	if(current)
		current->job->run_time += 1; /* ��1����1000ms */
	for(p = LV1_head; p != NULL; p = p->next){
			p->job->wait_time += 1000;
	}
	/* ������ҵ2�ȴ�ʱ�估���ȼ� */
	for(p = LV2_head, prev = LV2_head; p != NULL; prev = p, p = p->next){
		p->job->wait_time += 1000;
		if(p->job->wait_time >= 10000){
			p->job->curpri++;
			printf("job %d is updataed to LV1",p->job->jid);
			if(p == prev){
				LV2_head = LV2_head->next;
			}
			else{
				prev->next = p->next;
			}
			p -> next = NULL;
			if(LV1_head){
				for(q = LV1_head; q->next != NULL; q = q->next);
				q -> next = p;
			}
			else
				LV1_head = p;
			p->job->wait_time = 0;
		}
	}
	/*������ҵ3�ȴ�ʱ�估���ȼ�*/
	for(p = LV3_head, prev = LV3_head; p != NULL; prev = p, p = p->next){
		p->job->wait_time += 1000;
		if(p->job->wait_time >= 10000){
			p->job->curpri++;
			printf("job %d is updataed to LV2",p->job->jid);
			if(p == prev){
				LV3_head = LV3_head->next;
			}
			else{
				prev->next = p->next;
			}
			p -> next = NULL;
			if(LV2_head){
				for(q = LV2_head; q->next != NULL; q = q->next);
				q -> next = p;
			}
			else
				LV2_head = p;
			p->job->wait_time = 0;
		}
	}
}

struct waitqueue* jobselect()
{
	struct waitqueue *p,*prev,*select,*selectprev;
	int highest = -1;

	select = NULL;
	selectprev = NULL;
	if(LV1_head){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ 
		for(prev = LV1_head, p = LV1_head; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			if (select == selectprev)
				LV1_head = LV1_head->next;
			else
				selectprev->next = select->next;
		*/
		select = LV1_head;
		LV1_head = LV1_head->next;
		
	}
	else if(LV2_head){
		if(counter%2 == 0){
			select = LV2_head;
			LV2_head = LV2_head->next;
		}
	}
	else if(LV3_head){
		if(counter%5 == 0){
			select = LV3_head;
			LV3_head = LV3_head->next;
		}
	}
	else{counter = -1;}//��֤������µ���ҵ������ҵ��,������һ��ʱ��Ƭִ��
	if(select){

		//printf("The selected job's jid is %d, curpri is %d\n",select->job->jid, select->job->curpri);
		//printf("The counter is %d\n",counter);
		select->next = NULL;
		counter = 0;
	}
	return select;
}

void jobswitch()
{
	struct waitqueue *p;
	int i;

	if(current && current->job->state == DONE){ /* ��ǰ��ҵ��� */
		/* ��ҵ��ɣ�ɾ���� */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* �ͷſռ� */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}

	if(next == NULL && current == NULL) /* û����ҵҪ���� */

		return;
	else if (next != NULL && current == NULL){ /* ��ʼ�µ���ҵ */

		printf("begin start new job\n");
		//printf("jid:%d pid:%d\n",next->job->jid,next->job->pid);//for debug
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		
		kill(current->job->pid,SIGCONT);
		return;
	}
	else if (next != NULL && current != NULL){ /* �л���ҵ */

		printf("switch to Pid: %d\n",next->job->pid);
		kill(current->job->pid,SIGSTOP);
		
		if(current->job->curpri == 1);
		else
			current->job->curpri -= 1;
		
		//current->job->curpri = current->job->defpri;
		current->job->wait_time = 0;
		current->job->state = READY;

		/* �Żصȴ����� */
		if(current->job->curpri == 3){
			if(LV1_head){
				for(p = LV1_head; p->next != NULL; p = p->next);
				p->next = current;
			}else{
				LV1_head = current;
			}
		}
		else if(current->job->curpri == 2){
			if(LV2_head){
				for(p = LV2_head; p->next != NULL; p = p->next);
				p->next = current;
			}else{
				LV1_head = current;
			}
		}
		else if(current->job->curpri == 1){
			if(LV3_head){
				for(p = LV3_head; p->next != NULL; p = p->next);
				p->next = current;
			}else{
				LV3_head = current;
			}
		}
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		current->job->wait_time = 0;
		kill(current->job->pid,SIGCONT);
		return;
	}else{ /* next == NULL��current != NULL�����л� */
		return;
	}
}

void sig_handler(int sig,siginfo_t *info,void *notused)
{
	int status;
	int ret;

	switch (sig) {
case SIGVTALRM: /* �����ʱ�������õļ�ʱ��� */
#ifdef DEBUG
	//printf("SIGVTALRM RECEIVED!\n");
#endif
	scheduler();
	return;
case SIGCHLD: /* �ӽ��̽���ʱ���͸������̵��ź� */
	ret = waitpid(-1,&status,WNOHANG);
	if (ret == 0)
		return;
	if(WIFEXITED(status)){
		current->job->state = DONE;
		printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
	}else if (WIFSIGNALED(status)){
		printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
	}else if (WIFSTOPPED(status)){
		printf("child stopped, signal number = %d\n",WSTOPSIG(status));
	}
#ifdef DEBUG
	printf("SIGCHLD RECEIVED!\n");
	printimformation();
#endif
	return;
	default:
		return;
	}
}

void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd)
{
	struct waitqueue *newnode,*p;
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;

	sigemptyset(&zeromask);

	/* ��װjobinfo���ݽṹ */
	newjob = (struct jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();
	newjob->defpri = enqcmd.defpri;
	newjob->curpri = enqcmd.defpri;
	newjob->ownerid = enqcmd.owner;
	newjob->state = READY;
	newjob->create_time = time(NULL);
	newjob->wait_time = 0;
	newjob->run_time = 0;
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));
	newjob->cmdarg = arglist;
	offset = enqcmd.data;
	argvec = enqcmd.data;
	while (i < enqcmd.argnum){
		if(*offset == ':'){
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;

#ifdef DEBUG

	printf("enqcmd argnum %d\n",enqcmd.argnum);
	for(i = 0;i < enqcmd.argnum; i++)
		printf("parse enqcmd:%s\n",arglist[i]);

#endif

	/*��ȴ������������µ���ҵ*/
	newnode = (struct waitqueue*)malloc(sizeof(struct waitqueue));
	newnode->next =NULL;
	newnode->job=newjob;
	if(current == NULL || newnode->job->defpri > current->job->curpri){
		next = newnode;
	}
	else{
		if(newjob->defpri == 3){
			if(LV1_head)
			{
				for(p=LV1_head;p->next != NULL; p=p->next);
				p->next =newnode;
			}else
				LV1_head=newnode;
		}
		else if(newjob->defpri == 2){
			if(LV2_head)
			{
				for(p=LV2_head;p->next != NULL; p=p->next);
				p->next =newnode;
			}else
				LV2_head=newnode;
		}
		else{
			if(LV3_head)
			{
				for(p=LV3_head;p->next != NULL; p=p->next);
				p->next =newnode;
			}else
				LV3_head=newnode;
		}
			
	}

	/*Ϊ��ҵ��������*/
	if((pid=fork())<0)
		error_sys("enq fork failed");

	if(pid==0){
		newjob->pid =getpid();
		/*�����ӽ���,�ȵ�ִ��*/
		raise(SIGSTOP);
#ifdef DEBUG

		printf("begin running\n");
		for(i=0;arglist[i]!=NULL;i++)
			printf("arglist %s\n",arglist[i]);
#endif

		/*�����ļ�����������׼���*/
		dup2(globalfd,1);
		/* ִ������ */
		if(execv(arglist[0],arglist)<0)
			printf("exec failed\n");
		exit(1);
	}else{
		//sleep(1);//test
		waitpid(pid,NULL,WUNTRACED);
		newjob->pid=pid;
	}
}

void do_deq(struct jobcmd deqcmd)
{
	int deqid,i;
	struct waitqueue *p,*prev,*select,*selectprev;
	deqid=atoi(deqcmd.data);

#ifdef DEBUG
	printf("deq jid %d\n",deqid);
#endif

	/*current jodid==deqid,��ֹ��ǰ��ҵ*/
	if (current && current->job->jid ==deqid){
		printf("teminate current job\n");
		kill(current->job->pid,SIGKILL);
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{ /* �����ڵȴ������в���deqid */
		select=NULL;
		selectprev=NULL;
		if(LV1_head){
			for(prev=LV1_head,p=LV1_head;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
			if(select == NULL);
			else if(select==selectprev)
				LV1_head=LV1_head->next;
			else
				selectprev->next=select->next;
		}
		if(select == NULL && LV2_head){
			for(prev=LV2_head,p=LV2_head;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
			if(select == NULL);
			else if(select==selectprev)
				LV2_head=LV2_head->next;
			else
				selectprev->next=select->next;
		}
		if(select == NULL && LV3_head){
			for(prev=LV3_head,p=LV3_head;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
			if(select == NULL);
			else if(select==selectprev)
				LV3_head=LV3_head->next;
			else
				selectprev->next=select->next;
		}
		if(select){
			for(i=0;(select->job->cmdarg)[i]!=NULL;i++){
				free((select->job->cmdarg)[i]);
				(select->job->cmdarg)[i]=NULL;
			}
			free(select->job->cmdarg);
			free(select->job);
			free(select);
			select=NULL;
		}
	}
}

void do_stat(struct jobcmd statcmd)
{
	struct waitqueue *p;
	char timebuf[BUFLEN];
	struct stat statbuf2;
	char string0 [10000];
	char tmp[10000];
	int fifo2;
	//char string2[1000];
	//char string3[1000];
	/*
	*��ӡ������ҵ��ͳ����Ϣ:
	*1.��ҵID
	*2.����ID
	*3.��ҵ������
	*4.��ҵ����ʱ��
	*5.��ҵ�ȴ�ʱ��
	*6.��ҵ����ʱ��
	*7.��ҵ״̬
	*/

	/* ��ӡ��Ϣͷ�� */
	string0[0]='\0';
	tmp[0]='\0';
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	sprintf(tmp,"JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	strcat(string0,tmp);
	tmp[0]='\0';
	if(current){
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
		sprintf(tmp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
		strcat(string0,tmp);
		tmp[0]='\0';
	}
	//strcat(string0,tmp);
	//tmp[0]='\0';
	for(p=LV1_head;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		sprintf(tmp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		strcat(string0,tmp);
		tmp[0]='\0';
	}
	for(p=LV2_head;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		sprintf(tmp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		strcat(string0,tmp);
		tmp[0]='\0';
	}
	for(p=LV3_head;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		sprintf(tmp,"%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
		strcat(string0,tmp);
		tmp[0]='\0';
	}
	if((fifo2=open("/tmp/server2",O_WRONLY|O_NONBLOCK))<0){
		error_sys("current fifo failed");
	}
	if(write(fifo2,string0,10000)<0){
		error_sys("current write failed");
	}
}
void printimformation(){
	struct waitqueue *p;
	char timebuf[BUFLEN];
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if(current){
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
	}

	for(p=LV1_head;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			(p->job->state == READY)?"READY":"DONE");
	}
	for(p=LV2_head;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			(p->job->state == READY)?"READY":"DONE");
	}
	for(p=LV3_head;p!=NULL;p=p->next){
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			(p->job->state == READY)?"READY":"DONE");
	}
}
int main()
{
	struct timeval interval;
	struct itimerval new,old;
	struct stat statbuf;
	struct sigaction newact,oldact1,oldact2;
#ifdef DEBUG
	printf("DEBUG IS OPEN!");
#endif
	if(stat("/tmp/server",&statbuf)==0){
		/* ���FIFO�ļ�����,ɾ�� */
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/server",0666)<0)
		error_sys("mkfifo failed");
	/* �ڷ�����ģʽ�´�FIFO */
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)
		error_sys("open fifo failed");

	/* �����źŴ������� */
	newact.sa_sigaction=sig_handler;
	sigemptyset(&newact.sa_mask);
	newact.sa_flags=SA_SIGINFO;
	sigaction(SIGCHLD,&newact,&oldact1);
	sigaction(SIGVTALRM,&newact,&oldact2);

	/* ����ʱ����Ϊ1000���� */
	interval.tv_sec=1;
	interval.tv_usec=0;

	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);

	while(siginfo==1);

	close(fifo);
	close(globalfd);
	return 0;
}


