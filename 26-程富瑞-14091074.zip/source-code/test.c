#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>

int main(){
	int pid;
	pid = fork();
	if (pid < 0){
		printf("Fork failed.");	
	}
	else if(pid == 0){
		raise(SIGSTOP);
		printf("%d restart",getpid());
		return 1;
	}
	else{
		kill(pid,SIGCONT);
	}
	
}
