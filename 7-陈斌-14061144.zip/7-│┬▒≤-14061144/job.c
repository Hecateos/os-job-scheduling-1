#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include "job.h"

int jobid=0;
int siginfo=1;
int fifo;
int fifo_stat;
int globalfd;
int slccnt=0;
int slctable[3]={4,1,0};
struct timeval interval;
struct itimerval new,old;
struct waitqueue *head[3]={};
struct waitqueue *next=NULL,*current =NULL;

/* ���ȳ��� */
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	int  count = 0;
	bzero(&cmd,DATALEN);
	if((count=read(fifo,&cmd,DATALEN))<0)
		error_sys("read fifo failed");
#ifdef DEBUG

	if(count){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);
	}
	else
		printf("no data read\n");
#endif

	/* ���µȴ������е���ҵ */
/*
	#ifdef DEBUG
		printf("Update jobs in wait queue!\n"); 
	#endif
*/
	switch(cmd.type){
	case ENQ:
		do_enq(newjob,cmd);
		break;
	case DEQ:
		do_deq(cmd);
		break;
	case STAT:
		do_stat(cmd);
		break;
	default:
		break;
	}
	if(next!=NULL){
/*
#ifdef DEBUG
		printf("Switch to next job!\n");
#endif
*/
		jobswitch();
		slccnt=0;
	}
	else if(current==NULL||slccnt>=slctable[current->job->curpri]){
/*
#ifdef DEBUG
		printf("Select which job to run next!\n");
#endif
*/
		next=jobselect();
		jobswitch();
		slccnt=0;
	}
}

int allocjid()
{
	return ++jobid;
}

void updateall()
{
	struct waitqueue *p;
	struct waitqueue *prev=NULL;
	struct waitqueue *q;
	struct waitqueue *t;
    int i;
/*
#ifdef DEBUG
	//���updateallִ�к��������ҵ��Ϣ
	printf("Before updateall execute--------------------------------\n");
	for(i=0;i<3;i++) {
		for(p = head[i]; p != NULL; p = p->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				p->job->jid,p->job->pid,p->job->defpri,p->job->curpri,p->job->wait_time,p->job->run_time,p->job->state);
		}
	}
#endif
*/
	/* ������ҵ����ʱ�� */
	if(current)
		current->job->run_time += 1; /* ��1����1000ms */

	/* ������ҵ�ȴ�ʱ�估���ȼ� */
	for(i = 0; i < 3; i ++)
        for(p = head[i],prev=head[i]; p != NULL; prev=p,p = p->next){
            p->job->wait_time += 1000;
            if(p->job->wait_time >= 10000 && p->job->curpri < 2){
                p->job->curpri++;
                p->job->wait_time = 0;
		if(head[p->job->curpri]){
	                for(q = head[p->job->curpri]; q->next != NULL; q = q->next);
	                q->next = p;
		}
		else
			head[p->job->curpri]=p;
		prev->next=p->next;
		if(p==prev){
			if(p->next==NULL)
				head[i]=NULL;
			else
				head[i]=p->next;
				p->next=NULL;
		}
            }
        }
/*
#ifdef DEBUG
	/////���updateallִ�к��������ҵ��Ϣ
	printf("After updateall execute--------------------------------\n");
	for(i=0;i<3;i++) {
		for(p = head[i]; p != NULL; p = p->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				p->job->jid,p->job->pid,p->job->defpri,p->job->curpri,p->job->wait_time,p->job->run_time,p->job->state);
		}
	}
#endif
*/
}

struct waitqueue* jobselect()
{
	struct waitqueue *p,*prev,*select,*selectprev;
	int highest = -1;
    	int i;
	select = NULL;
	selectprev = NULL;
	for(i=2;i>=(current==NULL? 0:current->job->defpri);i--)
        if(head[i]){
            /* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
            select = head[i];
            selectprev = head[i];
            if(select->next == NULL)
                head[i] = NULL;
            else{
                head[i] = select->next;
                select->next=NULL;
            }
	    printf("selectpri:%d listorder:%d defpri:%d \n",i,select->job->curpri,select->job->defpri);
	    break;
        }
/*
#ifdef DEBUG
	if(select!=NULL) {
	printf("The job that is selected\n");
	printf("Job jid\t%d\n"
		"Job pid\t%d\n"
		"Job defpri\t%d\n"
		"Job curpri\t%d\n"
		"Job wait_time\t%d\n"
		"Job run_time\t%d\n"
		"Job state\t%d\n",
		select->job->jid,select->job->pid,select->job->defpri,select->job->curpri,select->job->wait_time,select->job->run_time,select->job->state);
}
#endif
*/

	return select;
}

void jobswitch()
{
	struct waitqueue *p;
	int i;
/*
#ifdef DEBUG
	printf("Before jobswitch execute,The current job info\n");
	printf("Job jid\t%d\n"
		"Job pid\t%d\n"
		"Job defpri\t%d\n"
		"Job curpri\t%d\n"
		"Job wait_time\t%d\n"
		"Job run_time\t%d\n"
		"Job state\t%d\n",
		current->job->jid,current->job->pid,current->job->defpri,current->job->curpri,current->job->wait_time,current->job->run_time,current->job->state);
#endif
*/

	if(current && current->job->state == DONE){ /* ��ǰ��ҵ��� */
		/* ��ҵ��ɣ�ɾ���� */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* �ͷſռ� */
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current = NULL;
	}
	if(next == NULL && current == NULL) /* û����ҵҪ���� */
		return;
	else if (next != NULL && current == NULL){ /* ��ʼ�µ���ҵ */
/*
	#ifdef DEBUG
	printf("Last process is DONE,The current job info\n");
	printf("Job jid\t%d\n"
		"Job pid\t%d\n"
		"Job defpri\t%d\n"
		"Job curpri\t%d\n"
		"Job wait_time\t%d\n"
		"Job run_time\t%d\n"
		"Job state\t%d\n",
		current->job->jid,current->job->pid,current->job->defpri,current>job->curpri,current->job->wait_time,
		current->job->run_time,current->job->state);
	#endif
*/
		printf("begin start new job\n");
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		kill(current->job->pid,SIGCONT);
        	setitimer(ITIMER_REAL,&new,NULL);
		return;
	}
	else if (next != NULL && current != NULL){ /* �л���ҵ */
		printf("switch to Pid: %d\n",next->job->pid);
		printf("curpri:%d defpri:%d\n",next->job->curpri,next->job->defpri);
		kill(current->job->pid,SIGSTOP);
		current->job->curpri = current->job->defpri;
		current->job->wait_time = 0;
		current->job->state = READY;
		/* �Żصȴ����� */
		if(head[current->job->curpri]){
			for(p = head[current->job->curpri]; p->next != NULL; p = p->next);
			p->next = current;
		}else{
			head[current->job->curpri] = current;
		}
		current = next;
		next = NULL;
	        setitimer(ITIMER_REAL,&new,NULL);
		current->job->state = RUNNING;
		current->job->wait_time = 0;
		kill(current->job->pid,SIGCONT);
		return;
	}else{ /* next == NULL��current != NULL�����л� */
		return;
	}

/*
#ifdef DEBUG
	printf("After jobswitch execute,The current job info\n");
	printf("Job jid\t%d\n"
		"Job pid\t%d\n"
		"Job defpri\t%d\n"
		"Job curpri\t%d\n"
		"Job wait_time\t%d\n"
		"Job run_time\t%d\n"
		"Job state\t%d\n",
		current->job->jid,current->job->pid,current->job->defpri,current>job->curpri,current->job->wait_time,
		current->job->run_time,current->job->state);
#endif
*/
}

void sig_handler(int sig,siginfo_t *info,void *notused)
{
	int status;
	int ret;
	switch (sig) {
case SIGALRM: /* �����ʱ�������õļ�ʱ��� */
	updateall();
	slccnt++;
	return;
        break;
case SIGCHLD: /* �ӽ��̽���ʱ���͸������̵��ź� */
	ret = waitpid(-1,&status,WNOHANG);
	if (ret == 0)
		return;
	if(WIFEXITED(status)){
		current->job->state = DONE;
		printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
	}else if (WIFSIGNALED(status)){
		printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
	}else if (WIFSTOPPED(status)){
		printf("child stopped, signal number = %d\n",WSTOPSIG(status));
	}
	return;
        break;
	default:
		return;
	}
}

void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd)
{
	struct waitqueue *newnode,*p,*temp;
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;

	sigemptyset(&zeromask);

/*
  #ifdef DEBUG
	
	printf("Before enq execute--------------------------------\n");
	for(j=0;j<3;j++) {
		for(pp = head[j]; pp != NULL; pp= pp->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				pp->job->jid,pp->job->pid,pp->job->defpri,pp->job->curpri,pp->job->wait_time,pp->job->run_time,pp->job->state);
		}
	}
  #endif 
*/
	/* ��װjobinfo���ݽṹ */
	newjob = (struct jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();
	newjob->defpri = enqcmd.defpri;
	newjob->curpri = enqcmd.defpri;
	newjob->ownerid = enqcmd.owner;
	newjob->state = READY;
	newjob->create_time = time(NULL);
	newjob->wait_time = 0;
	newjob->run_time = 0;
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));
	newjob->cmdarg = arglist;
	offset = enqcmd.data;
	argvec = enqcmd.data;
	while (i < enqcmd.argnum){
		if(*offset == ':'){
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;

#ifdef DEBUG

	printf("enqcmd argnum %d\n",enqcmd.argnum);
	for(i = 0;i < enqcmd.argnum; i++)
		printf("parse enqcmd:%s\n",arglist[i]);

#endif

	/*��ȴ������������µ���ҵ*/
	newnode = (struct waitqueue*)malloc(sizeof(struct waitqueue));
	newnode->next =NULL;
	newnode->job=newjob;
	/*Ϊ��ҵ��������*/
	pid=fork();
	if(pid<0)
		error_sys("enq fork failed");
	if(pid==0){
		newjob->pid =getpid();
		/*�����ӽ���,�ȵ�ִ��*/
		raise(SIGSTOP);
#ifdef DEBUG

		printf("begin running\n");
		for(i=0;arglist[i]!=NULL;i++)
			printf("arglist %s\n",arglist[i]);
#endif
		/*�����ļ�����������׼���*/
		dup2(globalfd,1);
		/* ִ������ */
		if(execv(arglist[0],arglist)<0)
			printf("exec failed\n");
		exit(1);
	}else{
		sleep(2);
		newjob->pid=pid;
	}
    	if(head[newjob->curpri])
	{
		for(p=head[newjob->curpri];p->next != NULL; p=p->next);
		p->next =newnode;
	}else
		head[newjob->curpri]=newnode;
	if(current&&current->job->curpri < newjob->curpri){
		next=newnode;
            	if(newnode->next == NULL)
           	    head[newjob->curpri] = NULL;
            	else{
                    head[newjob->curpri] = newnode->next;
	            newnode->next=NULL;
        	}
	}
/*
#ifdef DEBUG
	//���enqִ�к��������ҵ��Ϣ
	printf("BEfore enq execute--------------------------------\n");
	for(j=0;j<3;j++) {
		for(pp = head[j]; pp != NULL; pp= pp->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				pp->job->jid,pp->job->pid,pp->job->defpri,pp->job->curpri,pp->job->wait_time,pp->job->run_time,pp->job->state);
		}
	}
#endif
*/

}

void do_deq(struct jobcmd deqcmd)
{
	int deqid,i;
	struct waitqueue *p,*prev,*select,*selectprev;
	deqid=atoi(deqcmd.data);

#ifdef DEBUG
	printf("deq jid %d\n",deqid);
#endif

/*
#ifdef DEBUG
	// ���deqִ��qian��������ҵ��Ϣ
	printf("Before deq execute--------------------------------\n");
	for(j=0;j<3;j++) {
		for(pp = head[j]; pp != NULL; pp= pp->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				pp->job->jid,pp->job->pid,pp->job->defpri,pp->job->curpri,pp->job->wait_time,pp->job->run_time,pp->job->state);
		}
	}
#endif
*/

	/*current jodid==deqid,��ֹ��ǰ��ҵ*/
	if (current && current->job->jid ==deqid){
		printf("teminate current job\n");
		kill(current->job->pid,SIGKILL);
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{ /* �����ڵȴ������в���deqid */
		select=NULL;
		selectprev=NULL;
		for(i=0;i<3;i++){
            if(head[i]){
                for(prev=head[i],p=head[i];p!=NULL;prev=p,p=p->next)
                    if(p->job->jid==deqid){
                        select=p;
                        selectprev=prev;
                        break;
                    }
                if(p!=NULL){
                    selectprev->next=select->next;
                    if (select == selectprev){
                        if(select->next==NULL)
                        head[i] = NULL;
                        else{
            				head[i] = select->next;
                            select->next=NULL;
                        }
                    }
                }
            }
            if(select!=NULL)
                break;
		}
		if(select){
			for(i=0;(select->job->cmdarg)[i]!=NULL;i++){
				free((select->job->cmdarg)[i]);
				(select->job->cmdarg)[i]=NULL;
			}
			free(select->job->cmdarg);
			free(select->job);
			free(select);
			select=NULL;
		}
	}

/*
#ifdef DEBUG
	//���deqִ��hou��������ҵ��Ϣ
	printf("After deq execute--------------------------------\n");
	for(j=0;j<3;j++) {
		for(pp = head[j]; pp != NULL; pp= pp->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				pp->job->jid,pp->job->pid,pp->job->defpri,pp->job->curpri,pp->job->wait_time,pp->job->run_time,pp->job->state);
		}
	}
#endif
*/

}

void do_stat(struct jobcmd statcmd)
{
	struct waitqueue *p;
	int i;
	char timebuf[BUFLEN];

/*
#ifdef DEBUG
	//���statִ��qian��������ҵ��Ϣ
	printf("Before stat execute--------------------------------\n");
	for(j=0;j<3;j++) {
		for(pp = head[j]; pp != NULL; pp= pp->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				pp->job->jid,pp->job->pid,pp->job->defpri,pp->job->curpri,pp->job->wait_time,pp->job->run_time,pp->job->state);
		}
	}
#endif
*/
	/*
	*��ӡ������ҵ��ͳ����Ϣ:
	*1.��ҵID
	*2.����ID
	*3.��ҵ������
	*4.��ҵ����ʱ��
	*5.��ҵ�ȴ�ʱ��
	*6.��ҵ����ʱ��
	*7.��ҵ״̬
	*/

	/* ��ӡ��Ϣͷ�� */
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if((fifo_stat=open("/tmp/server_stat",O_WRONLY|O_NONBLOCK))<0)
			error_sys("stat open fifo_stat failed");
	if(current==NULL)
		single_fifo = 1;
	if(current){
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';

		/*��fifo_stat����ҵ��Ϣд��stat������*////
		if(write(fifo_stat,current->job,sizeof(struct jobinfo))<0)
			error_sys("stat write failed");

		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
	}
    for(i=0;i<3;i++)
        for(p=head[i];p!=NULL;p=p->next){
            strcpy(timebuf,ctime(&(p->job->create_time)));
            timebuf[strlen(timebuf)-1]='\0';
		/*��fifo_stat����ҵ��Ϣд��stat������*////
	    if(write(fifo_stat,p->job,sizeof(struct jobinfo))<0)
		   error_sys("stat write failed");
            printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
                p->job->jid,
                p->job->pid,
                p->job->ownerid,
                p->job->run_time,
                p->job->wait_time,
                timebuf,
                "READY");
        }
close(fifo_stat);
/*
#ifdef DEBUG
	//���statִ��hou��������ҵ��Ϣ
	printf("After stat execute--------------------------------\n");
	for(j=0;j<3;j++) {
		for(pp = head[j]; pp != NULL; pp= pp->next){
			 printf("Job jid\t%d\n"
				"Job pid\t%d\n"
				"Job defpri\t%d\n"
				"Job curpri\t%d\n"
				"Job wait_time\t%d\n"
				"Job run_time\t%d\n"
				"Job state\t%d\n",
				pp->job->jid,pp->job->pid,pp->job->defpri,pp->job->curpri,pp->job->wait_time,pp->job->run_time,pp->job->state);
		}
	}
#endif
*/
}

int main()
{
	struct stat statbuf;
	struct stat statbuf_stat;
	struct sigaction newact,oldact1,oldact2;

        if(stat("/tmp/server",&statbuf)==0){  // ���FIFO�ļ�����,ɾ��
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	///stat fifo
	if(stat("/tmp/server_stat",&statbuf_stat)==0){  // ���FIFO�ļ�����,ɾ��
		if(remove("/tmp/server_stat")<0)
			error_sys("remove failed");
	}


	if(mkfifo("/tmp/server",0666)<0)
		error_sys("mkfifo failed");

	// �ڷ�����ģʽ�´�FIFO
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)
		error_sys("open fifo failed");

		///stat fifo
	if(mkfifo("/tmp/server_stat",0666)<0)
		error_sys("mkfifo_stat failed");

	// �����źŴ�������
	newact.sa_sigaction=sig_handler;
	sigemptyset(&newact.sa_mask);
	newact.sa_flags=SA_SIGINFO;
	sigaction(SIGCHLD,&newact,&oldact1);
	sigaction(SIGALRM,&newact,NULL);//&oldact2

	// ����ʱ����Ϊ1000����
	interval.tv_sec=1;
	interval.tv_usec=0;
	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_REAL,&new,NULL);
	while(siginfo==1){
		scheduler();
		sleep(1);
	}
	close(fifo);
	close(globalfd);
	return 0;
}

