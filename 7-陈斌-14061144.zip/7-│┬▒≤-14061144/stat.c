#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include "job.h"
//#define DEBUG

/* 
 * �����﷨��ʽ
 *     stat
 */
void usage()
{
	printf("Usage: stat\n");		
}

int main(int argc,char *argv[])
{
	struct jobinfo newjob;
	struct jobcmd statcmd;
        int fd; 
	int fd_stat;
	int count=0;
	char timebuf[BUFLEN];

	if(argc!=1)
	{
		usage();
		return 1;
	}

	statcmd.type=STAT;
	statcmd.defpri=0;
	statcmd.owner=getuid();
	statcmd.argnum=0;

#ifdef DEBUG
		printf("statcmd cmdtype\t%d (-1 neans ENQ,-2 means DEQ,-3 means STAT)\n"
			"statcmd owner\t%d\n"
			"statcmd defpri\t%d\n"
			"statcmd argnum\t%d\n",
			statcmd.type,statcmd.owner,statcmd.defpri,statcmd.argnum);

#endif 




	if((fd=open("/tmp/server",O_WRONLY))<0)
		error_sys("stat open fifo failed");

	if(write(fd,&statcmd,DATALEN)<0)
		error_sys("stat write failed");

	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if((fd_stat=open("/tmp/server_stat",O_RDONLY))<0)
			error_sys("stat open fifo failed");
	while((count=read(fd_stat,&newjob,sizeof(struct jobinfo)))<=0) {
		if(single_fifo = 1) {
			single_fifo = 0;
			close(fd);
			close(fd_stat);
			return 0;
		}
	}
			//error_sys("stat read failed");
 	do{
	//strcpy(timebuf,ctime( &(newjob.create_time) ) );
	//	timebuf[strlen(timebuf)-1]='\0';
	if(newjob.state == 2) {
		printf("%d\t%d\t%d\t%d\t%d\t%d\t%s\n",
				newjob.jid,
				newjob.pid,
				newjob.ownerid,
				newjob.run_time,
				newjob.wait_time,
				newjob.create_time,"RUNNING");
	}
	else {
		printf("%d\t%d\t%d\t%d\t%d\t%d\t%s\n",
				newjob.jid,
				newjob.pid,
				newjob.ownerid,
				newjob.run_time,
				newjob.wait_time,
				newjob.create_time,"READY");
	}
	bzero(&newjob,sizeof(struct jobinfo));

	}while((count=read(fd_stat,&newjob,sizeof(struct jobinfo)))>0);

	close(fd);
	close(fd_stat);
	return 0;
}
