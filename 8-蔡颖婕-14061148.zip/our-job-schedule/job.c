#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include "job.h"
#define DEBUG
int jobid=0;
int siginfo=1;
int fifo;
int globalfd;
int timer=0;
int waiting=1;

waitqueue *head[3]={NULL};
waitqueue *next=NULL,*current=NULL,*newwq=NULL;

/* 调度程序 */
void scheduler()
{
	jobinfo *newjob=NULL;
	jobcmd cmd;
	int  count = 0;
	bzero(&cmd,DATALEN);
	if((count=read(fifo,&cmd,DATALEN))<0)
		error_sys("read fifo failed");
		/*#ifdef DEBUG
		printf("Reading whether other process send command!\n");
		if(count){
			printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);
		}
		else
			printf("no data read\n");
		#endif

		/* 更新等待队列中的作业 */
		/*#ifdef DEBUG
			printf("Update jobs in wait queue!\n");
			// 输出更新前所有作业的相关信息
		#endif
		#ifdef DEBUG
		printf("-----------更新前，所有任务的信息。------------\n");
		show_stat();
		#endif */
	updateall();
		/*//输出更新后所有作业的相关信息
		#ifdef DEBUG
		printf("-----------更新后，所有任务的信息。------------\n");
		show_stat();
		#endif 
		//#ifdef DEBUG
		//printf("Execute command!\n");
		//#endif*/
	switch(cmd.type){
	case ENQ:
			/*#ifdef DEBUG
			printf("Execute enq!\n");
			#endif
			#ifdef DEBUG
			printf("------------------------在执行enq之前的所有任务信息-----------------------\n");
			show_stat();
			#endif*/
		do_enq(newjob,cmd);
			/*#ifdef DEBUG
			printf("------------------------在执行enq之后的所有任务信息-----------------------\n");
			show_stat();
			#endif*/
		break;
	case DEQ:
			/*#ifdef DEBUG
			printf("Execute deq!\n");
			#endif
			#ifdef DEBUG
			printf("-----------------------在执行deq之前的所有任务信息------------------------\n");
			show_stat();
			#endif*/
		do_deq(cmd);
			/*#ifdef DEBUG
			printf("-----------------------在执行deq之后的所有任务信息------------------------\n");
			show_stat();
			#endif*/
		break;
	case STAT:
			/*#ifdef DEBUG
			printf("-------Execute stat!\n");
			#endif
			#ifdef DEBUG
			printf("-----------------------在执行stat之前的所有任务信息-----------------------\n");
			show_stat();
			#endif*/
		do_stat(cmd);
			/*#ifdef DEBUG
			printf("-----------------------在执行stat之后的所有任务信息-----------------------\n");
			show_stat();
			#endif*/
		break;
	default:
		break;
	}

	/* 选择高优先级作业 */
	#ifdef DEBUG
	printf("Select which job to run next!\n");
	#endif
	next=jobselect();

	#ifdef DEBUG
	printf("----------------------选择的任务的信息-------------\n");
	show_waitinfo(next);
	#endif

	/* 作业切换 */
	/*#ifdef DEBUG
	printf("Switch to the next job!\n");
	#endif	
	#ifdef DEBUG
	printf("jobswitch前,正在执行的作业和等待队列中任务的情况。\n"); 
	show_stat();
	#endif	*/

	jobswitch();

	/*#ifdef DEBUG
	printf("jobswitch后,正在执行的作业和等待队列中任务的情况。\n"); 
	show_stat();
	#endif*/	
}

int allocjid()
{
	return ++jobid;
}
void show_waitinfo(waitqueue *p){
	if(p!=NULL){
		char timebuf[BUFLEN];
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,"READY");
	}
	
	
}
void show_stat()
{
	waitqueue *p;
	int i;
	char timebuf[BUFLEN];
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if(current){
		printf("Running job:\n");
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,
			"RUNNING");
	}
	for(i=0;i<3;i++){
		printf("Wait queue of priority %d:\n",i+1);
		for(p=head[i];p!=NULL;p=p->next){
			strcpy(timebuf,ctime(&(p->job->create_time)));
			timebuf[strlen(timebuf)-1]='\0';
			printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
				p->job->jid,
				p->job->pid,
				p->job->ownerid,
				p->job->run_time,
				p->job->wait_time,
				timebuf,
				"READY");
		}
	}
}
void show_stat2()
{
	waitqueue *p;
	int i;
	char timebuf[BUFLEN];
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if(current){
		printf("DONE job:\n");
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,
			"DONE");
	}
	for(i=0;i<3;i++){
		printf("Wait queue of priority %d:\n",i+1);
		for(p=head[i];p!=NULL;p=p->next){
			strcpy(timebuf,ctime(&(p->job->create_time)));
			timebuf[strlen(timebuf)-1]='\0';
			printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
				p->job->jid,
				p->job->pid,
				p->job->ownerid,
				p->job->run_time,
				p->job->wait_time,
				timebuf,
				"READY");
		}
	}
}
void updateall()
{
	waitqueue *p,*prev,*t;
	int i;

	/* 更新作业运行时间 */
	if(current)
		current->job->run_time += 1; /* 加1代表1000ms */
	/* 更新作业等待时间及优先级 */
	for(i=2;i>=0;i--){//优先级从高往低进行调整，以免等待时间被重复增加。
		for(p = head[i],prev = head[i]; p != NULL; prev = p,p = p->next){
			p->job->wait_time += 1000;
			if(p->job->wait_time >= 10000 && p->job->curpri < 3){
				p->job->curpri++;
				p->job->wait_time = 0;
				//【MAJOR】从原来的队列里搬到新的队列里去。
				#ifdef DEBUG
				printf("升级\n");
				#endif
				t = head[p->job->curpri-1];
				if(t){
					for(;t->next != NULL;t = t->next);
					t->next = p;
				}
				else
					head[p->job->curpri-1] = p;
				t = p->next;
				prev->next = p->next;
				p->next = NULL;
				if(p!=prev)
					p = prev;
				else{
					if(t){
						head[i] = t;
						prev = p = head[i];
					}
					else{
						head[i] = NULL;
						break;
					}
				}
			}
		}
	} 
}

waitqueue* jobselect()
{
	waitqueue *select=NULL,*p,*prev;
	int i,max_time=0;
	if(current){
		switch(current->job->curpri){
			case 1 : max_time = 5;break;
			case 2 : max_time = 2;break;
			case 3 : max_time = 1;break;
		}
		if(timer<max_time){
			select = current;
			timer++;
		}
		else{
			timer = 0;
			for(i=2;i>=0;i--){
				if(head[i]==NULL)
					continue;
				else if(i+1>=current->job->curpri){
					select = head[i];
					head[i] = select->next;
					break;
				}
			}
		}
	}
	else{
		for(i=2;i>=0;i--){
			if(head[i]==NULL)
				continue;
			else{
				select = head[i];
				head[i] = select->next;
				break;
			}
		}
	}
	if(newwq){
		if(newwq->job->curpri>=select->job->curpri){
			#ifdef DEBUG
			printf("抢占\n");
			#endif
			if(select!=current)
				head[i] = select;
			select = newwq;
			for(p=head[newwq->job->curpri-1],prev=head[newwq->job->curpri-1];p->next!=NULL;prev=p,p=p->next);
			if(p==prev)
				head[newwq->job->curpri-1]=NULL;
			else
				prev->next=NULL;
		}
		newwq = NULL;
	}
	if(select!=NULL){
		select->next = NULL;
	}
	
	return select;
}

void jobswitch()
{
	waitqueue *p;
	int i;

	if(current && current->job->state == DONE){ /* 当前作业完成 */
		/* 作业完成，删除它 */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* 释放空间 */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}

	if(next == NULL && current == NULL) /* 没有作业要运行 */

		return;
	else if (next != NULL && current == NULL){ /* 开始新的作业 */
		#ifdef  DEBUG
		printf("start new job\n");
		#endif
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		kill(current->job->pid,SIGCONT);
		return;
	}
	else if (next != NULL && current != NULL && current!=next){ /* 切换作业 */
		#ifdef DEBUG
		printf("switch to Pid: %d\n",next->job->pid);
		#endif
		kill(current->job->pid,SIGSTOP);
		//current->job->curpri = current->job->defpri;
		current->job->wait_time = 0;
		current->job->state = READY;

		/* 放回等待队列 */
		if(head[current->job->curpri-1]){
			#ifdef DEBUG
			printf("放回队列: %d\n",current->job->curpri);
			#endif
			for(p = head[current->job->curpri-1]; p->next != NULL; p = p->next);
			p->next = current;
		}else{
			head[current->job->curpri-1] = current;
		}
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		current->job->wait_time = 0;
		kill(current->job->pid,SIGCONT);
		return;
	}else{ /* next == NULL且current != NULL，或next == current，不切换 */
		return;
	}
}

void sig_handler(int sig,siginfo_t *info,void *notused)
{
	int status;
	int ret;

	switch(sig){
		case SIGVTALRM: /* 到达计时器所设置的计时间隔 */
			scheduler();
			#ifdef DEBUG
			printf("SIGVTALRM RECEIVE!\n");
			#endif
			return;
		case SIGCHLD: /* 子进程结束时传送给父进程的信号 */
			ret = waitpid(-1,&status,WNOHANG);
			if(ret == 0)
				return;
			if(WIFEXITED(status)){
				current->job->state = DONE;
				#ifdef DEBUG
				printf("当子进程结束，传递信号之后的任务情况：\n");
				show_stat2();
				#endif
				current = NULL;
				timer = 0;
				scheduler();
				printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
			}
			else if (WIFSIGNALED(status)){
				printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
			}
			else if (WIFSTOPPED(status)){
				printf("child stopped, signal number = %d\n",WSTOPSIG(status));
			}
			return;
		default:
			return;
	}
}

void do_enq(jobinfo *newjob,jobcmd enqcmd)
{
	waitqueue *newnode,*p;
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;

	sigemptyset(&zeromask);

	/* 封装jobinfo数据结构 */
	newjob = (jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();
	newjob->defpri = enqcmd.defpri;
	newjob->curpri = enqcmd.defpri;
	newjob->ownerid = enqcmd.owner;
	newjob->state = READY;
	newjob->create_time = time(NULL);
	newjob->wait_time = 0;
	newjob->run_time = 0;
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));
	newjob->cmdarg = arglist;
	offset = enqcmd.data;
	argvec = enqcmd.data;
	while (i < enqcmd.argnum){
		if(*offset == ':'){
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;

	#ifdef DEBUG
	printf("enqcmd argnum %d\n",enqcmd.argnum);
	for(i = 0;i < enqcmd.argnum; i++)
		printf("parse enqcmd:%s\n",arglist[i]);
	#endif

	/*向等待队列中增加新的作业*/
	newnode = (waitqueue*)malloc(sizeof(waitqueue));
	newnode->next =NULL;
	newnode->job=newjob;
	newwq = newnode;

	if(head[enqcmd.defpri-1])
	{
		for(p=head[enqcmd.defpri-1];p->next != NULL; p=p->next);
		p->next =newnode;
	}else
		head[enqcmd.defpri-1]=newnode;

	/*为作业创建进程*/
	if((pid=fork())<0)
		error_sys("enq fork failed");

	if(pid==0){//子进程
		newjob->pid =getpid();
		kill(getppid(),SIGUSR1);
		/*阻塞子进程,等待执行*/
		raise(SIGSTOP);
		#ifdef DEBUG
		printf("begin running\n");
		for(i=0;arglist[i]!=NULL;i++)
			printf("arglist %s\n",arglist[i]);
		#endif

		/*复制文件描述符到标准输出*/
		dup2(globalfd,1);
		/* 执行命令 */
		if(execv(arglist[0],arglist)<0)
			printf("exec failed\n");
		exit(1);
	}else{//父进程
		newjob->pid=pid;
		while(waiting);
		waiting = 1;
	}
}
// 信号处理函数
void su1_handler(){
	waiting = 0;
}

void do_deq(jobcmd deqcmd)
{
	int deqid,i,j;
	waitqueue *t,*p,*prev,*select,*selectprev;
	deqid=atoi(deqcmd.data);

	#ifdef DEBUG
	printf("deq jid %d\n",deqid);
	#endif

	/*current jobid==deqid,终止当前作业*/
	if (current && current->job->jid == deqid){
		#ifdef DEBUG
		printf("teminate current job\n");
		#endif
		kill(current->job->pid,SIGKILL);
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{
		for(i = 0;i<3;i++){
			for(p = head[i],prev = head[i];p != NULL;prev = p,p = p->next){
				if(p->job->jid == deqid){
					#ifdef DEBUG
					printf("remove from queue\n");
					#endif
					if(prev!=p)
						prev->next = p->next;
					else{
						head[i]=NULL;
					}
					for(j=0;(p->job->cmdarg)[j]!=NULL;j++){
						free((p->job->cmdarg)[j]);
						(p->job->cmdarg)[j]=NULL;
					}
					free(p->job->cmdarg);
					free(p->job);
					free(p);
					return;
				}
			}
		}
	}
}

void do_stat(jobcmd statcmd)
{
	waitqueue *p;
	datapack dp;
	int i;
	char timebuf[BUFLEN];
	int statfifo;
	/*
	*打印所有作业的统计信息:
	*1.作业ID
	*2.进程ID
	*3.作业所有者
	*4.作业运行时间
	*5.作业等待时间
	*6.作业创建时间
	*7.作业状态
	*/

	/* 和stat进程通信 */
	if(access("stat_fifo",F_OK)!=0){
		printf("stat_fifo not exists\n");
	}
	if((statfifo = open("stat_fifo",O_WRONLY))==-1){
		printf("open stat_fifo for write failed\n");
	}

	/* 打印信息头部 */
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	if(current){
		printf("Running job:\n");
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
		dp.jid = current->job->jid;dp.pid = current->job->pid;
		dp.ownerid = current->job->ownerid;dp.run_time = current->job->run_time;
		dp.wait_time = current->job->wait_time;
		strcpy(dp.timebuf,timebuf);
		strcpy(dp.status,"RUNNING");
		if(write(statfifo,&dp,sizeof(datapack))<0)
			printf("write stat_fifo failed\n");
		dp.jid = 0;
		if(write(statfifo,&dp,sizeof(datapack))<0)
			printf("write stat_fifo failed\n");
	}
	for(i=0;i<3;i++){
		printf("Wait queue of priority %d:\n",i+1);
		for(p=head[i];p!=NULL;p=p->next){
			strcpy(timebuf,ctime(&(p->job->create_time)));
			timebuf[strlen(timebuf)-1]='\0';
			printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
				p->job->jid,
				p->job->pid,
				p->job->ownerid,
				p->job->run_time,
				p->job->wait_time,
				timebuf,
				"READY");
			dp.jid = p->job->jid;dp.pid = p->job->pid;
			dp.ownerid = p->job->ownerid;dp.run_time = p->job->run_time;
			dp.wait_time = p->job->wait_time;
			strcpy(dp.timebuf,timebuf);
			strcpy(dp.status,"READY");
			if(write(statfifo,&dp,sizeof(datapack))<0)
				printf("write stat_fifo failed\n");
		}
		dp.jid = 0;
		if(write(statfifo,&dp,sizeof(datapack))<0)
			printf("write stat_fifo failed\n");
	}
	dp.jid = 0;
	if(write(statfifo,&dp,sizeof(datapack))<0)
		printf("write stat_fifo failed\n");
	close(statfifo);
}

int main()
{
	struct timeval interval;
	struct itimerval new,old;
	struct stat statbuf;
	struct sigaction newact,oldact1,oldact2;
	#ifdef DEBUG
		printf("DEBUG MODE IS RUNNING!\n");
	#endif
	if(stat("/tmp/server",&statbuf)==0){
		/* 如果FIFO文件存在,删掉 */
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/server",0666)<0)
		error_sys("mkfifo failed");
	/* 在非阻塞模式下打开FIFO */
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)
		error_sys("open fifo failed");

	/* 建立信号处理函数 */
	newact.sa_sigaction=sig_handler;
	sigemptyset(&newact.sa_mask);
	newact.sa_flags=SA_SIGINFO;

	sigaction(SIGCHLD,&newact,&oldact1);
	sigaction(SIGVTALRM,&newact,&oldact2);
	
	// 注册信号处理方式
	signal(SIGUSR1,su1_handler);
	/* 设置时间间隔为1000毫秒 */
	interval.tv_sec=1;
	interval.tv_usec=0;

	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);

	while(siginfo==1);

	close(fifo);
	close(globalfd);
	return 0;
}
