#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include "job.h"
//#ifndef DEBUG
	#define DEBUG
//#endif

//#undef DEBUG
int waiting_fifo = 1;
/* 
 * �����﷨��ʽ
 *     stat
 */
void usage()
{
	printf("Usage: stat\n");		
}

int main(int argc,char *argv[])
{
	jobcmd statcmd;
	int fd;
	datapack dp;
	waitqueue *head[3];
	waitqueue *current,*p;
	int i;
	char timebuf[BUFLEN];

	if(argc!=1)
	{
		usage();
		return 1;
	}

	statcmd.type=STAT;
	statcmd.defpri=0;
	statcmd.owner=getuid();
	statcmd.argnum=0;

	if((fd=open("/tmp/server",O_WRONLY))<0)
		error_sys("stat open fifo failed");

	if(write(fd,&statcmd,DATALEN)<0)
		error_sys("stat write failed");
	#ifdef DEBUG
		printf("statcmd cmdtype\t%d(-1 means ENQ,-2 means DEQ,-3 means STAT)\n"
			"statcmd owner\t%d\n"
			"statcmd defpri\t%d\n"
			"statcmd data\t%s\n"
			"statcmd argnum\t%d\n",
			statcmd.type,statcmd.owner,statcmd.defpri,statcmd.data,statcmd.argnum);
   	#endif 
	close(fd);
	//��job����ͨ�ţ���ʾstat��Ϣ��
	if(access("stat_fifo",F_OK)==0){//���stat_fifo���ڣ���ôɾȥ��
		if(remove("stat_fifo")<0)
			printf("remove stat_fifo failed\n");
	}
	if(mkfifo("stat_fifo",0666)<0)
		printf("make stat_fifo failed\n");
	if((fd = open("stat_fifo",O_RDONLY))<0)
		printf("open stat_fifo for read failed\n");
	/* ��ӡ��Ϣͷ�� */
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	printf("Running job:\n");
	while(read(fd,&dp,sizeof(datapack))>0){
		if(dp.jid==0)
			break;
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			dp.jid,
			dp.pid,
			dp.ownerid,
			dp.run_time,
			dp.wait_time,
			dp.timebuf,
			dp.status);
	}
	for(i=0;i<3;i++){
		printf("Wait queue of priority %d:\n",i+1);
		while(read(fd,&dp,sizeof(datapack))>0){
			if(dp.jid==0)
				break;
			printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
				dp.jid,
				dp.pid,
				dp.ownerid,
				dp.run_time,
				dp.wait_time,
				dp.timebuf,
				dp.status);
		}
	}

	close(fd);
	return 0;
}
