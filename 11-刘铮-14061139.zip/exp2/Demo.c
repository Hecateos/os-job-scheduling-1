#include <time.h>
#include <stdio.h>

void main(int argv,char** args)
{
  time_t timer,timerc;
  clock_t start,finish;

  int count=0;  

  struct tm *timeinfo;
  start = clock();
  //time(&timer);//系统开始的时间
  	if(argv == 2){
		while(1)
		{
		   // time(&timerc);
		   // if((timerc-timer)>=1)//每过1秒打印
		   // {
		   //   printf("程序经过%d秒\n",count++);
		   //   timer=timerc;
		   // }
		  sleep(1);
		  count++;
		  printf("%s:程序经过%d秒\n",args[1],count);
		}
	}
	else{
		int total = atoi(args[1]);
		while(count<=total)
		{
		   // time(&timerc);
		   // if((timerc-timer)>=1)//每过1秒打印
		   // {
		   //   printf("程序经过%d秒\n",count++);
		   //   timer=timerc;
		   // }
		  sleep(1);
		  count++;
		  printf("%s:程序经过%d秒\n",args[2],count);
		}
	}
  
}