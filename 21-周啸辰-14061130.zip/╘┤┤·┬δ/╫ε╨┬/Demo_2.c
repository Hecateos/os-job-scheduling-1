#include <stdio.h>

void main(){
	int i = 0;
	printf("Demo_2 is running\n");
	while(i<20){
		i=i+1;
		sleep(1);
		printf("Demo_2 has running %d seconds.\n", i);
		fflush(stdout);
	}
	printf("Demo_2 is ending.\n");
}
