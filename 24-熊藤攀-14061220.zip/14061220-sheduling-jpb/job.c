#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include "job.h"

//#define DEBUG
#define DJFKLZ 

int jobid=0;
int siginfo=1;
int fifo,fifo2;
int globalfd;
//int needruntime=0;

//struct waitqueue **head=NULL;
struct waitqueue *head[3]={NULL,NULL,NULL};
//struct waitqueue *head1=NULL,*head2=NULL,*head3=NULL;
struct waitqueue *next=NULL,*current =NULL;

/* ���ȳ��� */
#ifndef DJFKLZ
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	struct waitqueue *q;
	int  count = 0;
	bzero(&cmd,DATALEN);
	if((count=read(fifo,&cmd,DATALEN))<0)
		error_sys("read fifo failed");
	#ifdef DEBUG
        
        printf("Reading whether other process send command!\n");
	if(count){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);
	}
	else
		printf("no data read\n");
	#endif

	/* ���µȴ������е���ҵ */
        #ifdef DEBUG
            printf("UPdate jobs in wait queue!\n");
        #endif
	updateall();
	//printf("aa\n");

	switch(cmd.type){
	case ENQ:

    #ifdef DEBUG
        printf("Execute enq!\n");
    #endif


	#ifdef DEBUG
	for(p=head[0];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[1];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[2];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	#endif
		do_enq(newjob,cmd);
		break;
	case DEQ:
                #ifdef DEBUG
                     printf("Execute deq!\n");
                #endif
		do_deq(cmd);
		break;
	case STAT:
                #ifdef DEBUG
                     printf("Execute stat!\n");
                #endif
		do_stat(cmd);
		break;
	default:
		break;
	}

	/* ѡ������ȼ���ҵ */

	#ifdef DEBUG
    printf("Select which job to run next!\n");
	#endif

	next=jobselect();
	/* ��ҵ�л� */

	#ifdef DEBUG
    printf("Switch to the next job!\n");
	#endif

	jobswitch();
}
#else
	
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	struct waitqueue *p=NULL;
	int  count = 0;
	int ifenq=0;
	int pri=0;
	
	bzero(&cmd,DATALEN);
	if((count=read(fifo,&cmd,DATALEN))<0)
		error_sys("read fifo failed");
	#ifdef DEBUG
	printf("Reading whether other process send command!\n");
	if(count){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);
	}
	#endif

	/* ���µȴ������е���ҵ */
	#ifdef DEBUG
	printf("Update jobs in wait queue!\n");
	#endif	
	#ifdef DEBUG
	for(p=head[0];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[1];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[2];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	#endif
	updateall2();
	
	#ifdef DEBUG
	for(p=head[0];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[1];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[2];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	#endif

	switch(cmd.type){
	case ENQ:
	#ifdef DEBUG
		printf("Execute enq!\n");
	#endif
		do_enq(newjob,cmd);
		ifenq=1;
		pri=cmd.defpri;
		break;
	case DEQ:
	#ifdef DEBUG
		printf("Execute deq!\n");
	#endif
		do_deq(cmd);
		break;
	case STAT:
	#ifdef DEBUG
		printf("Execute stat!\n");
	#endif
		do_stat(cmd);
		break;
	default:
		break;
	}
	#ifdef DEBUG
	for(p=head[0];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[1];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[2];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	#endif
	if(ifenq==1){
		if(current){
			if(pri > current->job->curpri){ //��ռʽ������
				//sleep(10);
			#ifdef DEBUG
				printf("Select which job to run next!\n");
			#endif
				next=jobselect2();
			#ifdef DEBUG
				printf("Switch to the next job!\n");
			#endif
				jobswitch2();
				//printf("%d",current->job->curpri);
				/*if(current){
					if(head[0]){
						needruntime=current->job->run_time+1;
					}
					else if(head[1]){
						needruntime=current->job->run_time+2;
					}
					else{
						needruntime=current->job->run_time+5;
					}
					*/
					switch(current->job->curpri){
						case 0:current->job->need_time=current->job->run_time+5;break;
						case 1:current->job->need_time=current->job->run_time+2;break;
						case 2:current->job->need_time=current->job->run_time+1;break;	
						default:break;
						
					
				}
			}
		}
	}
	ifenq=0;
	//sleep(0);
	//if(current)printf("%d",current->job->run_time);
	if(current){
		if(current->job->run_time>=current->job->need_time&&current->job->run_time!=0){
			#ifdef DEBUG
				printf("Select which job to run next!\n");
			#endif
				next=jobselect2();
			#ifdef DEBUG
				printf("Switch to the next job!\n");
			#endif
				jobswitch2();
				//printf("%d",current->job->curpri);
				/*if(head[0]){
					needruntime=current->job->run_time+1;
				}
				else if(head[1]){
					needruntime=current->job->run_time+2;
				}
				else{
					needruntime=current->job->run_time+5;
				}
				*/
				if(current){
						switch(current->job->curpri){
							case 0:current->job->need_time=current->job->run_time+5;break;
							case 1:current->job->need_time=current->job->run_time+2;break;
							case 2:current->job->need_time=current->job->run_time+1;break;	
							default:break;
						}
				}
				
		}
	}
	else{
	/* ѡ������ȼ���ҵ */
		#ifdef DEBUG
			printf("Select which job to run next!\n");
		#endif
		next=jobselect2();
	/* ��ҵ�л� */
		#ifdef DEBUG
			printf("Switch to the next job!\n");
		#endif
		jobswitch2();
		
		if(current){
			//printf("%d",current->job->curpri);
			/*if(head[0]){
				needruntime=current->job->run_time+1;
			}
			else if(head[1]){
				needruntime=current->job->run_time+2;
			}
			else{
				needruntime=current->job->run_time+5;
			}
			*/
			switch(current->job->curpri){
				case 0:current->job->need_time=current->job->run_time+5;break;
				case 1:current->job->need_time=current->job->run_time+2;break;
				case 2:current->job->need_time=current->job->run_time+1;break;	
				default:break;
			}
			
		}
	}
	#ifdef DEBUG
	if(current)printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",current->job->pid,current->job->defpri,current->job->curpri,current->job->ownerid,current->job->wait_time,current->job->run_time);
	else printf("current=null");
	for(p=head[0];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
			
	}
	for(p=head[1];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	for(p=head[2];p!=NULL;p=p->next){
		printf("jid:%d\tdefpri:%d\tcurpri:%d\townerid:%d\twait_time:%d\trun_time:%d\t",
			p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
	}
	#endif
}
#endif

int allocjid()
{
	return ++jobid;
}

void updateall()
{
//printf("updatil\n");
	struct waitqueue *p;
    struct waitqueue *q;
	/* ������ҵ����ʱ�� */
/*
#ifdef DEBUG
int 1=0;
for(i=0;i<2;i++){
    for(q = head[0]; q != NULL; q = q->next){
        printf("updateall_before jid\t%d\n"
		"updateall_before pid\t%d\n"
		"updateall_before defpri\t%d\n"
                "updateall_before curpri\t%d\n"
		"updateall_before ownerid\t%d\n"
                "updateall_before wait_time\t%d\n"
                "updateall_before run_time\t%d\n",
		q->job->jid,q->job->pid,q->job->defpri,q->job->curpri,q->job->ownerid,q->job->wait_time,q->job->run_time);
    }
}
#endif
*/
	if(current)
		current->job->run_time += 1; /* ��1����1000ms */

	/* ������ҵ�ȴ�ʱ�估���ȼ� */
	for(p = head[0]; p != NULL; p = p->next){
		p->job->wait_time += 1000;
		if(p->job->wait_time >= 5000 && p->job->curpri < 3){
			p->job->curpri++;
			p->job->wait_time = 0;
		}
	}
/*
#ifdef DEBUG
int i;
for(i=0;i<2;i++)
    for(q = head[0]; q != NULL; q = q->next){
        printf("updateall_after jid\t%d\n"
		"updateall_after pid\t%d\n"
		"updateall_after defpri\t%d\n"
                "updateall_after curpri\t%d\n"
		"updateall_after ownerid\t%d\n"
                "updateall_after wait_time\t%d\n"
                "updateall_after run_time\t%d\n",
		q->job->jid,q->job->pid,q->job->defpri,q->job->curpri,q->job->ownerid,q->job->wait_time,q->job->run_time);
    }
#endif
*/
}
void updateall2(){
	struct waitqueue *p;
	struct waitqueue *pre;
	struct waitqueue *temp,*tmp;
	/* ������ҵ����ʱ�� */
	
	if(current)
		current->job->run_time += 1; /* ��1����1000ms */

	/* ������ҵ�ȴ�ʱ�估���ȼ� */
	for(p = head[0]; p != NULL; p = p->next){
		p->job->wait_time += 1000;
	}
	for(p = head[1],pre=NULL; p != NULL; pre=p,p = p->next){
		p->job->wait_time += 1000;		
		if(p->job->wait_time >= 10000 && p->job->curpri < 2){//�ȴ�ʱ�䳬��ʮ�뵱ǰ���ȼ���һ
			(p->job->curpri)++;
			p->job->wait_time = 0;
			//for(temp= head[0]; temp!= NULL; temp = temp->next);
			//temp=p;
			//if(p!=head[1])pre->next=p->next;
			//p->next=NULL;
/*
			if(pre==NULL){
				head[1]=p->next;
				tmp->next=p->next;
				p=tmp;
			}
			else{
				pre->next=p->next;
				p=pre;
			}
*/
		}
	}
	for(p = head[2]; p != NULL;pre=p,p = p->next){
		p->job->wait_time += 1000;		
		if(p->job->wait_time >= 10000 && p->job->curpri < 2){
			(p->job->curpri)++;
			p->job->wait_time = 0;
			//for(temp= head[1]; temp!= NULL; temp = temp->next);
			//temp=p;
			//if(p!=head[2])pre->next=p->next;
			//p->next=NULL;
/*
			if(pre==NULL){
				head[2]=p->next;
				tmp->next=p->next;
				p=tmp;
			}
			else{
				pre->next=p->next;
				p=pre;
			}
*/
		}
	}
}

struct waitqueue* jobselect()
{
//printf("jobselect\n");
	struct waitqueue *p,*prev,*select,*selectprev;
	int highest = -1;

	select = NULL;
	selectprev = NULL;
	if(head[0]){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head[0], p = head[0]; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
                        if (select == selectprev){
                            if(select->next==NULL){
                                head[0]=NULL;
                            }
						else{
							head[0]=select->next;
                               select->next=NULL;
                            }
                       }
	}
        if(select!=NULL)

/*            select->next=NULL;
#ifdef DEBUG
    printf("jobselect jid\t%d\n"
		"jobselect pid\t%d\n"
		"jobselect defpri\t%d\n"
                "jobselect curpri\t%d\n"
		"jobselect ownerid\t%d\n"
                "jobselect wait_time\t%d\n"
                "jobselect run_time\t%d\n",
	select->job->jid,select->job->pid,select->job->defpri,select->job->curpri,select->job->ownerid,select->job->wait_time,select->job->run_time);

#endif
*/
	return select;
}

struct waitqueue* jobselect2()
{
	struct waitqueue *p,*prev,*select,*selectprev;
	int highest = -1;

	select = NULL;
	selectprev = NULL;
	if(head[0]){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head[0], p = head[0]; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
            if (select == selectprev){
                if(select->next==NULL){
                    head[0]=NULL;
                    }
					else{
					head[0]=select->next;
                    select->next=NULL;
                    }
            }
	}
	else if(head[1]){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head[1], p = head[1]; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev){
                if(select->next==NULL){
                    head[1]=NULL;
                    }
					else{
					head[1]=select->next;
                    select->next=NULL;
                    }
            }
	}
	else if(head[2]){
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head[2], p = head[2]; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev){
                if(select->next==NULL){
                    head[2]=NULL;
                    }
					else{
					head[2]=select->next;
                    select->next=NULL;
                    }
            }
  
	}

/*            select->next=NULL;
//#ifdef DEBUG
    printf("jobselect jid\t%d\n"
		"jobselect pid\t%d\n"
		"jobselect defpri\t%d\n"
                "jobselect curpri\t%d\n"
		"jobselect ownerid\t%d\n"
                "jobselect wait_time\t%d\n"
                "jobselect run_time\t%d\n",
	select->job->jid,select->job->pid,select->job->defpri,select->job->curpri,select->job->ownerid,select->job->wait_time,select->job->run_time);

//#endif
*/
	return select;
}


void jobswitch()
{
	struct waitqueue *p;
	int i;
	if(current && current->job->state == DONE){ /* ��ǰ��ҵ��� */
		/* ��ҵ��ɣ�ɾ���� */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* �ͷſռ� */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}
	//sleep(1);

	if(next == NULL && current == NULL) /* û����ҵҪ���� */
		return;
	else if (next != NULL && current == NULL){ /* ��ʼ�µ���ҵ */

		printf("begin start new job\n");
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		//sleep(1);
//printf("aaa  aaa  aaa\n");
                //waitpid(current->job->pid,NULL,WNOHANG);
		kill(current->job->pid,SIGCONT);
		return;
	}
	else if (next != NULL && current != NULL){ /* �л���ҵ */

		printf("switch to Pid: %d\n",next->job->pid);
//sleep(1);
		kill(current->job->pid,SIGSTOP);
		//current->job->curpri = current->job->defpri;
		current->job->wait_time = 0;
		current->job->state = READY;

		/* �Żصȴ����� */
		if((head[0])){
			for(p = head[0]; p->next != NULL; p = p->next);
			p->next = current;
		}else{
			head[0] = current;
		}
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		current->job->wait_time = 0;
		kill(current->job->pid,SIGCONT);
		return;
	}else{ /* next == NULL��current != NULL�����л� */
		return;
	}
}
void jobswitch2()
{
//printf("jobswitch");
	struct waitqueue *p;
	int i;

	if(current && current->job->state == DONE){ /* ��ǰ��ҵ��� */
		/* ��ҵ��ɣ�ɾ���� */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* �ͷſռ� */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}
//sleep(1);
	if(next == NULL && current == NULL) /* û����ҵҪ���� */

		return;
	else if (next != NULL && current == NULL){ /* ��ʼ�µ���ҵ */

		printf("begin start new job\n");
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		//sleep(1);
//printf("aaa  aaa  aaa\n");
//waitpid(current->job->pid,NULL,WNOHANG);
		kill(current->job->pid,SIGCONT);
		return;
	}
	else if (next != NULL && current != NULL){ /* ��ǰ��ҵδ��ɣ��л���ҵ */

		printf("switch to Pid: %d\n",next->job->pid);
//sleep(1);
		kill(current->job->pid,SIGSTOP);
		//current->job->curpri = current->job->defpri;	
		current->job->wait_time = 0;
		current->job->state = READY;

		/* �Żصȴ����� */
		if(current->job->curpri==2){
			current->job->curpri = 1;
			if(head[1]){
				for(p = head[1]; p->next != NULL; p = p->next);
				p->next = current;
			}else
				head[1]=current;
		}
		else if(current->job->curpri==1){
			current->job->curpri = 0;
			if(head[2]){
				for(p = head[2]; p->next != NULL; p = p->next);
				p->next = current;
			}else
				head[2]=current;
		}
		else if(current->job->curpri ==0){
			if(head[2]){
				for(p = head[2]; p->next != NULL; p = p->next);
				p->next = current;
			}else
				head[2]=current;
		}
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		current->job->wait_time = 0;
//sleep(1);
		kill(current->job->pid,SIGCONT);
		return;
	}else{ /* next == NULL��current != NULL�����л� */
		return;
	}
}

void sig_handler(int sig,siginfo_t *info,void *notused)
{
//printf("sig_handler");
	int status;
	int ret;

	switch (sig) {
case SIGVTALRM: /* �����ʱ�������õļ�ʱ��� */
	scheduler();

#ifdef DEBUG
    printf("SIGVTALRM RECEIVED!\n");
#endif

	return;
case SIGCHLD: /* �ӽ��̽���ʱ���͸������̵��ź� */
	ret = waitpid(-1,&status,WNOHANG);
	if (ret == 0)
		return;
	if(WIFEXITED(status)){
		if(current->job->run_time>0){
			current->job->state = DONE;
			printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
		}
		else{
		
			current->job->state = READY;
			printf("Due to time over,wait for getting more time by CPU");
		}
	}else if (WIFSIGNALED(status)){
		printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
	}else if (WIFSTOPPED(status)){
		printf("child stopped, signal number = %d\n",WSTOPSIG(status));
	}
	return;
	default:
		return;
	}
}

void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd)
{
//printf("do_enq");
//sleep(1);
	struct waitqueue *newnode,*p;
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;

	sigemptyset(&zeromask);

	/* ��װjobinfo���ݽṹ */
	newjob = (struct jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();
	newjob->defpri = enqcmd.defpri;
	newjob->curpri = enqcmd.defpri;
	newjob->ownerid = enqcmd.owner;
	newjob->state = READY;
	newjob->create_time = time(NULL);
	newjob->wait_time = 0;
	newjob->run_time = 0;
	newjob->need_time = 0;
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));
	newjob->cmdarg = arglist;
	offset = enqcmd.data;
	argvec = enqcmd.data;
	while (i < enqcmd.argnum){
		if(*offset == ':'){
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;

#ifdef DEBUG

	printf("enqcmd argnum %d\n",enqcmd.argnum);
	for(i = 0;i < enqcmd.argnum; i++)
		printf("parse enqcmd:%s\n",arglist[i]);

#endif

	/*��ȴ������������µ���ҵ*/
	newnode = (struct waitqueue*)malloc(sizeof(struct waitqueue));
	newnode->next =NULL;
	newnode->job=newjob;
//printf("%d",newjob->curpri);
	if(newjob->curpri==2)
	{
		if(head[0]){
			for(p=head[0];p->next != NULL; p=p->next);
			p->next =newnode;
		}else
		head[0]=newnode;
	}
	else if(newjob->curpri==1)
	{
		if(head[1]){
			for(p=head[1];p->next != NULL; p=p->next);
			p->next =newnode;
		}else
		head[1]=newnode;
	}
	else if(newjob->curpri==0)
	{
		if(head[2]){
			for(p=head[2];p->next != NULL; p=p->next);
			p->next =newnode;
		}else
		head[2]=newnode;
		
	}
#ifdef DEBUG
    printf("enq_after jid\t%d\n"
		"enq_after pid\t%d\n"
		"enq_after defpri\t%d\n"
                "enq_after curpri\t%d\n"
		"enq_after ownerid\t%d\n"
                "enq_after wait_time\t%d\n"
                "enq_after run_time\t%d\n",
		p->job->jid,p->job->pid,p->job->defpri,p->job->curpri,p->job->ownerid,p->job->wait_time,p->job->run_time);
#endif
#ifdef DEBUG
    printf("enq_after jid\t%d\n"
		"enq_after pid\t%d\n"
		"enq_after defpri\t%d\n"
                "enq_after curpri\t%d\n"
		"enq_after ownerid\t%d\n"
                "enq_after wait_time\t%d\n"
                "enq_after run_time\t%d\n",
		head[0]->job->jid,head[0]->job->pid,head[0]->job->defpri,head[0]->job->curpri,head[0]->job->ownerid,head[0]->job->wait_time,head[0]->job->run_time);
#endif


	/*Ϊ��ҵ��������*/
	if((pid=fork())<0)
		error_sys("enq fork failed");

	if(pid==0){
		newjob->pid =getpid();
		/*�����ӽ���,�ȵ�ִ��*/
//printf("bbb bbb bbb\n");
		raise(SIGSTOP);
#ifdef DEBUG

		printf("begin running\n");
		for(i=0;arglist[i]!=NULL;i++)
			printf("arglist %s\n",arglist[i]);
#endif

		/*�����ļ�����������׼���*/
		dup2(globalfd,1);
		/* ִ������ */
		if(execv(arglist[0],arglist)<0)
			printf("exec failed\n");
		exit(1);
	}else{
		sleep(1000);
		newjob->pid=pid;
		//waitpid(pid,NULL,0);
	}
}

void do_deq(struct jobcmd deqcmd)
{
//printf("do_deq");
	int deqid,i;
	struct waitqueue *p,*prev,*select,*selectprev;
	deqid=atoi(deqcmd.data);

#ifdef DEBUG
	printf("deq jid %d\n",deqid);
#endif

	/*current jodid==deqid,��ֹ��ǰ��ҵ*/
	if (current && current->job->jid ==deqid){
		printf("teminate current job\n");
		kill(current->job->pid,SIGKILL);
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{ /* �����ڵȴ������в���deqid */
		select=NULL;
		selectprev=NULL;
		for(i=0;i<=2;i++){
			for(prev=NULL,p=head[i];p!=NULL;prev=p,p=p->next){
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
				selectprev->next=select->next;
				if(select==selectprev){
                    head[i]=select->next;
					select->next=NULL;
                }
            }
		}
		if(select){
			for(i=0;(select->job->cmdarg)[i]!=NULL;i++){
				free((select->job->cmdarg)[i]);
				(select->job->cmdarg)[i]=NULL;
			}
			free(select->job->cmdarg);
			free(select->job);
			free(select);
			select=NULL;
		}
	}
}

void do_stat(struct jobcmd statcmd)
{
//printf("do_stat");
	struct waitqueue *p;
	char timebuf[BUFLEN];
	int ctr=0;char sprint[10000]; 
	int i=0;
	/*
	*��ӡ������ҵ��ͳ����Ϣ:
	*1.��ҵID
	*2.����ID
	*3.��ҵ������
	*4.��ҵ����ʱ��
	*5.��ҵ�ȴ�ʱ��
	*6.��ҵ����ʱ��
	*7.��ҵ״̬
	*/

	/* ��ӡ��Ϣͷ�� */
	ctr+=sprintf(sprint,"JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tPRI\tCREATTIME\tSTATE\n");
	if(current){
		strcpy(timebuf,ctime(&(current->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		ctr+=sprintf(sprint+ctr,"%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			current->job->curpri,
			timebuf,"RUNNING");
	}
	for(i=0;i<=2;i++){
		for(p=head[i];p!=NULL;p=p->next){
			strcpy(timebuf,ctime(&(p->job->create_time)));
			timebuf[strlen(timebuf)-1]='\0';
			ctr+=sprintf(sprint+ctr,"%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
				p->job->jid,
				p->job->pid,
				p->job->ownerid,
				p->job->run_time,
				p->job->wait_time,
				p->job->curpri,
				timebuf,
				"READY");
		}
	}
	ctr++;
	sprint[ctr]=-1;
	if((fifo2=open("/tmp/server2",O_WRONLY))<0)
		error_sys("open fifo2 failed");
	if(write(fifo2,sprint,ctr)<0)
		error_sys("stat write failed");
//printf("aaaa\n");
	close(fifo2);
}

int main()
{
	struct timeval interval;
	struct itimerval new,old;
	struct stat statbuf;
	struct sigaction newact,oldact1,oldact2;

#ifdef DEBUG
    printf("DEBUG IS OPEN!");
#endif

	if(stat("/tmp/server",&statbuf)==0){
		/* ���FIFO�ļ�����,ɾ�� */
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/server",0666)<0)
		error_sys("mkfifo failed");
	/* �ڷ�����ģʽ�´�FIFO */
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)
		error_sys("open fifo failed");

	/* �����źŴ������� */
	newact.sa_sigaction=sig_handler;
	sigemptyset(&newact.sa_mask);
	newact.sa_flags=SA_SIGINFO;
	sigaction(SIGCHLD,&newact,&oldact1);
	sigaction(SIGVTALRM,&newact,&oldact2);

	/* ����ʱ����Ϊ1000���� */
	interval.tv_sec=1;
	interval.tv_usec=0;

	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);

	while(siginfo==1);

	close(fifo);
        close(fifo2);
	close(globalfd);
	return 0;
}

