#include<stdio.h>
int main(){
	while (1){
		printf("程序3正在运行！！！！\n");
		sleep(1);
	}
	return 0;
}