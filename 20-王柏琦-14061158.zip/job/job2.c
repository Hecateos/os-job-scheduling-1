#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include "job.h"

int jobid=0;
int siginfo=1;
int fifo;
int globalfd;

struct waitqueue *head1=NULL,*head2=NULL,*head3=NULL;
struct waitqueue *next=NULL,*current =NULL;
struct timeval interval;
struct itimerval new,old;
void addUp(struct waitqueue *p);
/* ���ȳ��� */
void scheduler()
{
	struct jobinfo *newjob=NULL;
	struct jobcmd cmd;
	int  count = 0;
	bzero(&cmd,DATALEN);
	if((count=read(fifo,&cmd,DATALEN))<0)
		error_sys("read fifo failed");
#ifdef DEBUG

	if(count){
		printf("cmd cmdtype\t%d\ncmd defpri\t%d\ncmd data\t%s\n",cmd.type,cmd.defpri,cmd.data);
	}
	else
		printf("no data read\n");
#endif

	/* ���µȴ������е���ҵ */
	updateall();

	switch(cmd.type){
	case ENQ:
		do_enq(newjob,cmd);
		break;
	case DEQ:
		do_deq(cmd);
		break;
	case STAT:
		do_stat(cmd);
		break;
	default:
		break;
	}

	/* ѡ������ȼ���ҵ */
	next=jobselect();
	/*if(next!=NULL)
		printf("!null\n");
	else
		printf("null\n");*/
/*
if(next!=NULL){
	//printf("next curpri = %d\n",next->job->curpri);
	if(next->job->curpri==2)
	{
	interval.tv_sec=1;
	interval.tv_usec=0;
	}
	else if(next->job->curpri==0)
	{
	interval.tv_sec=5;
	interval.tv_usec=0;
	}
	else if(next->job->curpri==1)
	{
	interval.tv_sec=2;
	interval.tv_usec=0;
	}
	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);
	}*/
	/* ��ҵ�л� */
jobswitch();	
}

int allocjid()
{
	return ++jobid;
}

void updateall()
{
	struct waitqueue *p,*prev;
	//printf("update\n");
	/* ������ҵ����ʱ�� */
	if(current)
		current->job->run_time += 1; /* ��1����1000ms */

	/* ������ҵ�ȴ�ʱ�估���ȼ� */
	if(head1)
	for(p = head1; p != NULL; p = p->next){
		p->job->wait_time += 1000;
	}
	if(head2)
	for(p= head2,prev=NULL; p != NULL;){
		p->job->wait_time += 1000;
		if(p->job->wait_time >= 10000 && p->job->curpri < 2){
			p->job->curpri++;
			//printf("*****head2curpri==%d\n",p->job->curpri);
			addUp(p);
			//p->job->wait_time = 0;
			if(p==head2)
			{
				//printf("hihead2pid=%d\tnextpid=%d\tcurpid=%d\n",head2->job->pid,p->next->job->pid,current->job->pid);
				p=p->next;
				head3=p;
			}
			else
			{	//printf("hello\n");
				prev->next=p->next;
				p = p->next;
			}
			//if(p==head2)
			//head2=NULL;
			//if(p)
			//free(p);
			
			
		}
		else{	//printf("hahaha\n");
			prev = p;
			p = p->next;
		}
	}
	if(head3)
	for(p= head3,prev=NULL; p != NULL;){
		//printf("jid==%d,curpri==%d,wait_time==%d\n",p->job->jid,p->job->curpri,p->job->wait_time);
		p->job->wait_time += 1000;
		if(p->job->wait_time >= 10000 && p->job->curpri < 1){
			p->job->curpri++;
			//p->job->wait_time = 0;
			//printf("beforeup\n");
			addUp(p);
			//printf("afterup\n");
			//prev->next=p->next;
			if(p==head3)
			{
				//printf("hihead3pid=%d\tnextpid=%d\tcurpid=%d\n",head3->job->pid,p->next->job->pid,current->job->pid);
				p=p->next;
				head3=p;
			}
			else
			{	//printf("hello\n");
				prev->next=p->next;
				p = p->next;
			}
			//if(p==head3)
			//head2=NULL;
			//free(p);
		}
		else{	//printf("hahaha\n");
			prev = p;
			p = p->next;
		}
		//if(p!=NULL&&p->next!=NULL)
			//printf("for\tpid=%d\tnextpid=%d\thead3pid=%d\n",p->job->pid,p->next->job->pid,head3->job->pid);
	}
	//printf("updateover\n");
	
}

void addUp(struct waitqueue *p)
{
	struct waitqueue *tmp,*q;
	p->job->wait_time = 0;
	q=(struct waitqueue*)malloc(sizeof(struct waitqueue));
	q->job=p->job;
	q->next=NULL;
	if(p->job->curpri==2)
	{//printf("xxxxxxxxxxxxxxxxxxxxxxx%d\n",p->job->curpri);
		if(head1){
			for(tmp=head1;tmp->next!=NULL;tmp=tmp->next)
				;
			tmp->next=q;
		}
		else{
			head1=q;
		}
	}
	else if(p->job->curpri==1)
	{		
		if(head2){
			for(tmp=head2;tmp->next!=NULL;tmp=tmp->next)
				;
			tmp->next=q;
		}
		else{
			head2=q;
		}
	}
	else if(p->job->curpri==0)
	{	if(head3){
			for(tmp=head3;tmp->next!=NULL;tmp=tmp->next)
				;
			tmp->next=q;
		}
		else{
			head3=q;
		}
	}
}

struct waitqueue* jobselect()
{
	struct waitqueue *p,*prev,*select,*selectprev;
	int highest = -1;

	select = NULL;
	selectprev = NULL;
	if(head1){
		//printf("head1select\n");
		/* �����ȴ������е���ҵ���ҵ����ȼ���ߵ���ҵ */
		for(prev = head1, p = head1; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){//printf("hi1\n");
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev)
			{
				if(select->next==NULL)
					head1 = NULL;
				else{
					head1 = select->next;
					select->next=NULL;
				}
			}
	select->next=NULL;
	}
	else if(head2)
	{//printf("head2select\n");
		for(prev = head2, p = head2; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev)
			{
				if(select->next==NULL)
					head2 = NULL;
				else{
					head2 = select->next;
					select->next=NULL;
				}
			}
	select->next=NULL;
	}
	else if(head3)
	{//printf("head3select\n");
		for(prev = head3, p = head3; p != NULL; prev = p,p = p->next)
			if(p->job->curpri > highest){
				select = p;
				selectprev = prev;
				highest = p->job->curpri;
			}
			selectprev->next = select->next;
			if (select == selectprev)
			{
				if(select->next==NULL)
					head3 = NULL;
				else{
					head3 = select->next;
					select->next=NULL;
				}
			}
	select->next=NULL;
	}
	return select;
}

void jobswitch()
{
	struct waitqueue *p;
	int i;

	if(current && current->job->state == DONE){ /* ��ǰ��ҵ��� */
		/* ��ҵ��ɣ�ɾ���� */
		for(i = 0;(current->job->cmdarg)[i] != NULL; i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i] = NULL;
		}
		/* �ͷſռ� */
		free(current->job->cmdarg);
		free(current->job);
		free(current);

		current = NULL;
	}

	if(next == NULL && current == NULL) /* û����ҵҪ���� */

		return;
	else if (next != NULL && current == NULL){ /* ��ʼ�µ���ҵ */

		printf("begin start new job\n");
		current = next;
		next = NULL;
		current->job->state = RUNNING;
		sleep(1);
		kill(current->job->pid,SIGCONT);
		return;
	}
	else if (next != NULL && current != NULL){
		 /* �л���ҵ */
		//printf("1234567\tcurpri=%d\trun_time=%d\n",current->job->curpri,current->job->run_time);
/////////////////////////////////////////////////////////////////
		/*�ж��Ƿ���Ҫ��ʼ����ҵ*/
		if((current->job->curpri == 2&&current->job->run_time < 1)||(current->job->curpri == 1&&current->job->run_time < 2)||(current->job->curpri == 0&&current->job->run_time < 5)){
			if(next->job->curpri==2){
				if(head1){
					next->next = head1;
					head1 = next;
				}else{
					head1 = next;
				}
			}
			if(next->job->curpri==1){
				if(head2){
					next->next = head2;
					head2 = next;
				}else{
					head2 = next;
				}
			}
			if(next->job->curpri==0){
				if(head3){
					next->next = head3;
					head3 = next;
				}else{
					head3 = next;
				}
			}
			return;
		}	



/////////////////////////////////////////////////////////////////


		printf("switch to Pid: %d\n",next->job->pid);
		kill(current->job->pid,SIGSTOP);
		current->job->curpri = current->job->defpri;
		current->job->wait_time = 0;
		current->job->state = READY;
		current->job->run_time = 0;
		/* �Żصȴ����� */
		//

		if(current->job->curpri==2){
			if(head1){
				for(p = head1; p->next != NULL; p = p->next);
				p->next = current;
			}else{
				head1 = current;
			}
		}
		if(current->job->curpri==1){
			if(head2){
			
				for(p = head2; p->next != NULL; p = p->next);
				p->next = current;
			}else{
				head2 = current;
			}
		}
		if(current->job->curpri==0){//printf("put this 0 back");
			if(head3){
				for(p = head3; p->next != NULL; p = p->next);
				p->next = current;
			}else{
				head3 = current;
			}
		}
		current = next;
		//printf("current=next\n");
		next = NULL;
		current->job->state = RUNNING;
		current->job->wait_time = 0;
		kill(current->job->pid,SIGCONT);
		return;
	/*else//������ռ �Ž�����
	{
	if(next->job->curpri==2)
	{
		if(head1){
			for(p = head1; p->next != NULL; p = p->next);
			p->next = next;
		}else{
			head1 = next;
		}
	}
	else if(next->job->curpri==1)
	{
		if(head2){
			for(p = head2; p->next != NULL; p = p->next);
			p->next = next;
		}else{
			head2 = next;
		}
	}
	else if(next->job->curpri==0)
	{
		if(head3){
			for(p = head3; p->next != NULL; p = p->next);
			p->next = next;
		}else{
			head3 = next;
		}
	}
	}*/
	}else{ /* next == NULL��current != NULL�����л� */
		//printf("aaaa\n");
		return;
	}
}

void sig_handler(int sig,siginfo_t *info,void *notused)
{
	int status;
	int ret;

	switch (sig) {
case SIGVTALRM: /* �����ʱ�������õļ�ʱ��� */
		
	scheduler();
	return;
case SIGCHLD: /* �ӽ��̽���ʱ���͸������̵��ź� */
	ret = waitpid(-1,&status,WNOHANG);
	if (ret == 0)
		return;
	if(WIFEXITED(status)){
		current->job->state = DONE;
		printf("normal termation, exit status = %d\n",WEXITSTATUS(status));
	}else if (WIFSIGNALED(status)){
		printf("abnormal termation, signal number = %d\n",WTERMSIG(status));
	}else if (WIFSTOPPED(status)){
		printf("child stopped, signal number = %d\n",WSTOPSIG(status));
	}
	return;
	default:
		return;
	}
}

void do_enq(struct jobinfo *newjob,struct jobcmd enqcmd)
{
	struct waitqueue *newnode,*p;
	int i=0,pid;
	char *offset,*argvec,*q;
	char **arglist;
	sigset_t zeromask;

	sigemptyset(&zeromask);
	//printf("enq\n");
	/* ��װjobinfo���ݽṹ */
	newjob = (struct jobinfo *)malloc(sizeof(struct jobinfo));
	newjob->jid = allocjid();
	newjob->defpri = enqcmd.defpri;
	newjob->curpri = enqcmd.defpri;
	newjob->ownerid = enqcmd.owner;
	newjob->state = READY;
	newjob->create_time = time(NULL);
	newjob->wait_time = 0;
	newjob->run_time = 0;
	arglist = (char**)malloc(sizeof(char*)*(enqcmd.argnum+1));
	newjob->cmdarg = arglist;
	offset = enqcmd.data;
	argvec = enqcmd.data;
	while (i < enqcmd.argnum){
		if(*offset == ':'){
			*offset++ = '\0';
			q = (char*)malloc(offset - argvec);
			strcpy(q,argvec);
			arglist[i++] = q;
			argvec = offset;
		}else
			offset++;
	}

	arglist[i] = NULL;

#ifdef DEBUG

	printf("enqcmd argnum %d\n",enqcmd.argnum);
	for(i = 0;i < enqcmd.argnum; i++)
		printf("parse enqcmd:%s\n",arglist[i]);

#endif
	//printf("curpri=%d\n",newjob->curpri);
	/*��ȴ������������µ���ҵ*/
	newnode = (struct waitqueue*)malloc(sizeof(struct waitqueue));
	newnode->next =NULL;
	newnode->job=newjob;
	//printf("newnode.curpri==%d\n",newnode->job->curpri);
	if(newnode->job->curpri==2){
		if(head1){
			printf("head1\n");
			for(p=head1;p->next != NULL; p=p->next);
			p->next =newnode;
		}else{
			printf("head1\n");
			head1=newnode;
		}
	}
	else if(newnode->job->curpri==1){
		if(head2){
			printf("head2\n");
			for(p=head2;p->next != NULL; p=p->next);
			p->next =newnode;
		}else{
			printf("head2\n");
			head2=newnode;
			//printf("head==========newnode");
		}
	}
	else{
		if(head3){
			printf("head3\n");
			for(p=head3;p->next != NULL; p=p->next);
			p->next =newnode;
		}else{
			printf("head3\n");
			head3=newnode;
		}
	}

	/*Ϊ��ҵ��������*/
	if((pid=fork())<0)
		error_sys("enq fork failed");

	if(pid==0){
		newjob->pid =getpid();
		/*�����ӽ���,�ȵ�ִ��*/
		raise(SIGSTOP);
#ifdef DEBUG

		printf("begin running\n");
		for(i=0;arglist[i]!=NULL;i++)
			printf("arglist %s\n",arglist[i]);
#endif

		/*�����ļ�����������׼���*/
		dup2(globalfd,1);
		/* ִ������ */
		if(execv(arglist[0],arglist)<0)
			printf("exec failed\n");
		exit(1);
	}else{
		newjob->pid=pid;
	}
}

void do_deq(struct jobcmd deqcmd)
{
	int deqid,i;
	struct waitqueue *p,*prev,*select,*selectprev;
	deqid=atoi(deqcmd.data);

#ifdef DEBUG
	printf("deq jid %d\n",deqid);
#endif

	/*current jodid==deqid,��ֹ��ǰ��ҵ*/
	if (current && current->job->jid ==deqid){
		printf("teminate current job\n");
		kill(current->job->pid,SIGKILL);
		for(i=0;(current->job->cmdarg)[i]!=NULL;i++){
			free((current->job->cmdarg)[i]);
			(current->job->cmdarg)[i]=NULL;
		}
		free(current->job->cmdarg);
		free(current->job);
		free(current);
		current=NULL;
	}
	else{ /* �����ڵȴ������в���deqid */
		select=NULL;
		selectprev=NULL;
		if(head1){
			for(prev=head1,p=head1;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
				selectprev->next=select->next;
				if(select==selectprev)
				{
					if(select->next==NULL)
						head1=NULL;
					else{
						head1=select->next;
						select->next=NULL;
					}
				}
		}
		else if(head2){
			for(prev=head2,p=head2;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
				selectprev->next=select->next;
				if(select==selectprev)
				{
					if(select->next==NULL)
						head2=NULL;
					else{
						head2=select->next;
						select->next=NULL;
					}
				}
		}
		else if(head3){
			for(prev=head3,p=head3;p!=NULL;prev=p,p=p->next)
				if(p->job->jid==deqid){
					select=p;
					selectprev=prev;
					break;
				}
				selectprev->next=select->next;
				if(select==selectprev)
				{
					if(select->next==NULL)
						head3=NULL;
					else{
						head3=select->next;
						select->next=NULL;
					}
				}
		}
		if(select){
			for(i=0;(select->job->cmdarg)[i]!=NULL;i++){
				free((select->job->cmdarg)[i]);
				(select->job->cmdarg)[i]=NULL;
			}
			free(select->job->cmdarg);
			free(select->job);
			free(select);
			select=NULL;
		}
		else
			printf("jid dont exit.");
	}
}

void do_stat(struct jobcmd statcmd)
{
	struct waitqueue *p;
	struct jobinfo ajob;
	struct stat statbuf;
	int fifos;
	char timebuf[BUFLEN];
	/*
	*��ӡ������ҵ��ͳ����Ϣ:
	*1.��ҵID
	*2.����ID
	*3.��ҵ������
	*4.��ҵ����ʱ��
	*5.��ҵ�ȴ�ʱ��
	*6.��ҵ����ʱ��
	*7.��ҵ״̬
	*/
	

	if(stat("/tmp/stat",&statbuf)==0){
		/* ���FIFO�ļ�����,ɾ�� */
		if(remove("/tmp/stat")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/stat",0666)<0)
		error_sys("mkfifo failed");
	/* �ڷ�����ģʽ�´�FIFO */
	if((fifos=open("/tmp/stat",O_WRONLY))<0)
		error_sys("open fifo failed");

	/* ��ӡ��Ϣͷ�� */
	printf("JOBID\tPID\tOWNER\tRUNTIME\tWAITTIME\tCREATTIME\t\tSTATE\n");
	
	if(current){
		ajob=*current->job;
		if(write(fifos,&ajob,JOBLEN)<0)
		error_sys("stat write failed");
		strcpy(timebuf,ctime(&(current->job->create_time)));
//printf("%s\n",timebuf);
		timebuf[strlen(timebuf)-1]='\0';
		printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			current->job->jid,
			current->job->pid,
			current->job->ownerid,
			current->job->run_time,
			current->job->wait_time,
			timebuf,"RUNNING");
	}

	for(p=head1;p!=NULL;p=p->next){
		ajob=*p->job;
		if(write(fifos,&ajob,JOBLEN)<0)
		error_sys("stat write failed");
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("111111\n%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
	}
	for(p=head2;p!=NULL;p=p->next){
		ajob=*p->job;
		if(write(fifos,&ajob,JOBLEN)<0)
		error_sys("stat write failed");
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("22222222\n%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
	}
	for(p=head3;p!=NULL;p=p->next){
		ajob=*p->job;
		if(write(fifos,&ajob,JOBLEN)<0)
		error_sys("stat write failed");
		strcpy(timebuf,ctime(&(p->job->create_time)));
		timebuf[strlen(timebuf)-1]='\0';
		printf("33333333333\n%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			p->job->jid,
			p->job->pid,
			p->job->ownerid,
			p->job->run_time,
			p->job->wait_time,
			timebuf,
			"READY");
	}
	close(fifos);
}

int main()
{

	struct stat statbuf;
	struct sigaction newact,oldact1,oldact2;

	if(stat("/tmp/server",&statbuf)==0){
		/* ���FIFO�ļ�����,ɾ�� */
		if(remove("/tmp/server")<0)
			error_sys("remove failed");
	}

	if(mkfifo("/tmp/server",0666)<0)
		error_sys("mkfifo failed");
	/* �ڷ�����ģʽ�´�FIFO */
	if((fifo=open("/tmp/server",O_RDONLY|O_NONBLOCK))<0)
		error_sys("open fifo failed");

	/* �����źŴ������� */
	newact.sa_sigaction=sig_handler;
	sigemptyset(&newact.sa_mask);
	newact.sa_flags=SA_SIGINFO;
	sigaction(SIGCHLD,&newact,&oldact1);
	sigaction(SIGVTALRM,&newact,&oldact2);

	/* ����ʱ����Ϊ1000���� */
	interval.tv_sec=1;
	interval.tv_usec=0;

	new.it_interval=interval;
	new.it_value=interval;
	setitimer(ITIMER_VIRTUAL,&new,&old);

	while(siginfo==1);

	close(fifo);
	close(globalfd);
	return 0;
}
